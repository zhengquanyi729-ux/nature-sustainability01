# Data Files for Figures — Semiconductor Mega Cluster Manuscript

This directory contains structured CSV data files extracted from the research compiled for the manuscript "Resource requirements and localized sustainability consequences of the semiconductor Mega Cluster expansion in South Korea."

## File Index

| File | Description | Figure |
|------|-------------|--------|
| `fab_nodes.csv` | All 23 existing + 14 planned fab nodes with coordinates, technology, capacity, intensity factors | Figs 3, 6 |
| `water_stress_by_risk_category.csv` | Water withdrawal by risk category (Low to Extremely High) for 3 scenarios | Fig 2 |
| `water_scenario_comparison.csv` | Multi-SSP water stress results (SSP1-RCP2.6, SSP2-RCP4.5, SSP3-RCP7.0) | Fig 2, Supp Note 1 |
| `water_supply_demand_balance.csv` | Annual water supply vs demand 2024-2050 for 3 scenarios | Fig 2, Fig 3 |
| `pipeline_capacity.csv` | Water pipeline phases, capacities, investments, timelines | Fig 2 |
| `paldang_dam_specs.csv` | Paldang Dam specifications with active/live storage distinction | Fig 2, Fig 3 |
| `water_consumption_benchmarks.csv` | Water and energy per wafer by technology and process node | Methods |
| `electricity_cost_by_region.csv` | Marginal electricity costs by region and scenario | Fig 4a |
| `electricity_investment_costs.csv` | Annualized investment costs by category (generation, transmission, storage, RE100) | Fig 4b |
| `generation_mix.csv` | Korea generation mix 2024 actual and 2038 11th Plan projections | Fig 4 |
| `kepco_financial.csv` | KEPCO revenue, profit, debt, and grid investment data | Fig 4 |
| `land_use_by_scenario.csv` | Land requirements by category (direct fab, pipeline, rail, housing, etc.) | Fig 5a |
| `workforce_concentration.csv` | Workforce concentration, wage data, Gini coefficient | Fig 5b |
| `regional_population.csv` | Regional population shares, semiconductor employment, extinction risk | Fig 5b |
| `scenario_parameters.csv` | Key parameters across Baseline, AI-Explosion, Eco-Constraint | All figures |
| `xgb_shap_values.csv` | XGBoost/SHAP feature importance with 95% bootstrap confidence intervals | Fig 6 |

## Figure Mapping

- **Figure 2**: `water_stress_by_risk_category.csv` (2a), `water_scenario_comparison.csv` (2b)
- **Figure 3**: `fab_nodes.csv` (locations), `water_supply_demand_balance.csv`, `paldang_dam_specs.csv`
- **Figure 4a**: `electricity_cost_by_region.csv`
- **Figure 4b**: `electricity_investment_costs.csv`
- **Figure 5a**: `land_use_by_scenario.csv`
- **Figure 5b**: `workforce_concentration.csv`, `regional_population.csv`
- **Figure 6**: `xgb_shap_values.csv`, `fab_nodes.csv`

## Data Sources

All data compiled from open sources: WRI Aqueduct 4.0, KEPCO/KPX, K-water WAMIS,
KOSTAT, MOTIE, corporate sustainability reports (Samsung, SK Hynix, TSMC),
Korean government policy documents, and academic literature as referenced in
the manuscript.
