#!/usr/bin/env python3
"""
Pure-Python Shapefile & DBF Reader
-----------------------------------
Reads .shp (geometry) and .dbf (attributes) files with no external dependencies.
Supports: Point, PolyLine, Polygon, MultiPoint, PointM, PolyLineM, PolygonM
"""

import struct
import os
from collections import OrderedDict

# ── Shape Types ──
NULL        = 0
POINT       = 1
POLYLINE    = 3
POLYGON     = 5
MULTIPOINT  = 8
POINTM      = 21
POLYLINEM   = 23
POLYGONM    = 25


class ShpReader:
    """Read .shp geometry file."""

    def __init__(self, filepath):
        self.filepath = filepath
        self.shapes = []
        self.bbox = None
        self.shape_type = None
        self._read()

    def _read(self):
        with open(self.filepath, 'rb') as f:
            data = f.read()

        # ── 100-byte header (big-endian) ──
        header = struct.unpack_from('>7i4d4d', data, 0)
        # header format: file_code(4B), unused(20B), file_length(4B),
        #                version(4B), shape_type(4B),
        #                xmin,ymin,xmax,ymax(32B),
        #                zmin,zmax(16B), mmin,mmax(16B)
        self.file_code = header[0]
        self.file_length = header[2] * 2  # in bytes (was in 16-bit words)
        self.shape_type = header[4]
        self.bbox = (header[5], header[6], header[7], header[8])  # xmin,ymin,xmax,ymax

        # ── Records start at byte 100 ──
        pos = 100
        while pos < len(data):
            # 8-byte record header (big-endian)
            rec_num, content_length = struct.unpack_from('>2i', data, pos)
            rec_bytes = content_length * 2  # convert from 16-bit words to bytes
            pos += 8

            if pos + rec_bytes > len(data):
                break

            rec_data = data[pos:pos + rec_bytes]
            pos += rec_bytes

            shape = self._parse_record(rec_data)
            if shape is not None:
                shape['record_number'] = rec_num
                self.shapes.append(shape)

    def _parse_record(self, data):
        """Parse a single shape record."""
        if len(data) < 4:
            return None

        shtype = struct.unpack_from('<i', data, 0)[0]

        if shtype == NULL:
            return {'type': NULL, 'shape_type': 'Null'}

        elif shtype == POINT:
            x, y = struct.unpack_from('<2d', data, 4)
            return {'type': POINT, 'shape_type': 'Point', 'x': x, 'y': y}

        elif shtype == POINTM:
            x, y = struct.unpack_from('<2d', data, 4)
            m = struct.unpack_from('<d', data, 20)[0] if len(data) >= 28 else None
            return {'type': POINTM, 'shape_type': 'PointM', 'x': x, 'y': y, 'm': m}

        elif shtype in (POLYLINE, POLYGON, POLYLINEM, POLYGONM):
            return self._parse_poly(data, shtype)

        elif shtype == MULTIPOINT:
            return self._parse_multipoint(data)

        return None

    def _parse_poly(self, data, shtype):
        """Parse PolyLine or Polygon record."""
        # Box: 4 doubles (32 bytes)
        # NumParts: 1 int (4 bytes)
        # NumPoints: 1 int (4 bytes)
        # Parts: NumParts ints
        # Points: NumPoints * 2 doubles
        box = struct.unpack_from('<4d', data, 4)
        num_parts = struct.unpack_from('<i', data, 36)[0]
        num_points = struct.unpack_from('<i', data, 40)[0]

        parts_offset = 44
        parts = struct.unpack_from(f'<{num_parts}i', data, parts_offset)
        points_offset = parts_offset + num_parts * 4

        points = []
        for i in range(num_points):
            off = points_offset + i * 16
            x, y = struct.unpack_from('<2d', data, off)
            points.append((x, y))

        # Split into parts
        geometries = []
        for pi in range(num_parts):
            start = parts[pi]
            end = parts[pi + 1] if pi + 1 < num_parts else num_points
            geometries.append(points[start:end])

        type_name = 'PolyLine' if shtype in (POLYLINE, POLYLINEM) else 'Polygon'
        return {'type': shtype, 'shape_type': type_name,
                'bbox': box, 'parts': geometries}

    def _parse_multipoint(self, data):
        """Parse MultiPoint record."""
        box = struct.unpack_from('<4d', data, 4)
        num_points = struct.unpack_from('<i', data, 36)[0]
        points = []
        for i in range(num_points):
            off = 40 + i * 16
            x, y = struct.unpack_from('<2d', data, off)
            points.append((x, y))
        return {'type': MULTIPOINT, 'shape_type': 'MultiPoint',
                'bbox': box, 'points': points}


class DbfReader:
    """Read .dbf (dBase) attribute file."""

    def __init__(self, filepath, encoding='utf-8'):
        self.filepath = filepath
        self.encoding = encoding
        self.fields = []
        self.records = []
        self._read()

    def _read(self):
        with open(self.filepath, 'rb') as f:
            data = f.read()

        # Header
        version = data[0]
        num_records = struct.unpack_from('<I', data, 4)[0]
        header_len = struct.unpack_from('<H', data, 8)[0]
        record_len = struct.unpack_from('<H', data, 10)[0]

        # Parse field descriptors (each 32 bytes)
        pos = 32  # first field descriptor starts at byte 32 in standard header
        # Actually the header starts at byte 0, field descriptors at byte 32
        while pos < header_len - 1:
            if data[pos] == 0x0D:  # end of field descriptors
                break
            name_bytes = data[pos:pos+11]
            name = name_bytes.split(b'\x00')[0].decode(self.encoding, errors='replace')
            field_type = chr(data[pos+11])
            field_length = data[pos+16]
            decimal_count = data[pos+17]
            self.fields.append({
                'name': name,
                'type': field_type,
                'length': field_length,
                'decimal': decimal_count
            })
            pos += 32

        # Parse records
        record_start = header_len
        for i in range(num_records):
            offset = record_start + i * record_len
            if offset + record_len > len(data):
                break
            rec_data = data[offset:offset + record_len]
            deleted = rec_data[0] == 0x2A  # '*'
            if deleted:
                continue

            record = OrderedDict()
            field_pos = 1  # skip deletion flag
            for field in self.fields:
                raw = rec_data[field_pos:field_pos + field['length']]
                raw_str = raw.decode(self.encoding, errors='replace').strip()
                record[field['name']] = raw_str
                field_pos += field['length']
            self.records.append(record)

    def get_column(self, name):
        return [r.get(name) for r in self.records]

    @property
    def num_records(self):
        return len(self.records)


def load_shapefile(base_path):
    """Load .shp + .dbf pair. Returns (shapes, records, fields)."""
    shp_path = base_path + '.shp'
    dbf_path = base_path + '.dbf'

    shapes = ShpReader(shp_path)

    records = []
    fields = []
    if os.path.exists(dbf_path):
        dbf = DbfReader(dbf_path)
        records = dbf.records
        fields = dbf.fields

    return shapes, records, fields


def query_shapefile(base_path, field_filters=None, geometry_type=None, limit=0):
    """Load shapefile and filter records by field values.

    Args:
        base_path: path without extension (e.g., 'data/southkorea.shp/gis_osm_waterways_free_1')
        field_filters: dict of {field_name: value_or_list} to filter by
        geometry_type: optional geometry type filter (e.g., POLYLINE, POLYGON)
        limit: max number of records (0 = unlimited)

    Returns:
        list of (shape_dict, record_dict)
    """
    shapes, records, fields = load_shapefile(base_path)

    if field_filters is None:
        field_filters = {}

    result = []
    for i, (shape, record) in enumerate(zip(shapes.shapes, records)):
        if geometry_type is not None and shape['type'] != geometry_type:
            continue
        if limit > 0 and len(result) >= limit:
            break

        # Check field filters
        match = True
        for fname, fval in field_filters.items():
            rec_val = record.get(fname, '')
            if isinstance(fval, (list, tuple)):
                if rec_val not in fval:
                    match = False
                    break
            else:
                if rec_val != fval:
                    match = False
                    break

        if match:
            result.append((shape, record))

    return result
