#!/usr/bin/env python3
"""
SCSM — Semiconductor Cluster Spatial Model
===========================================
Core model for assessing multi-resource sustainability consequences of
semiconductor manufacturing cluster expansion.

The model takes as input:
  - Fab node database (37 nodes: 23 existing + 14 planned)
  - Three expansion scenarios (Baseline, AI-Explosion, Eco-Constraint)
  - External baseline data (water stress, electricity grid, demographics)

And produces:
  - Node-specific water and electricity demand projections (2024-2050)
  - Spatial load mapping to sub-basin and grid-node levels
  - Input data for downstream sustainability assessment modules

Reference:
  "Resource requirements and localized sustainability consequences
   of the semiconductor Mega Cluster expansion in South Korea"
  Nature Sustainability (submitted)
"""

import numpy as np
import pandas as pd
from pathlib import Path
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


# ═══════════════════════════════════════════════════════════════════════
# DATA STRUCTURES
# ═══════════════════════════════════════════════════════════════════════

@dataclass
class FabNode:
    """Single semiconductor fabrication node."""
    node_id: str
    company: str
    campus: str
    technology: str
    node_category: str  # 'Mature', 'Advanced', 'Leading-edge'
    status: str  # 'Existing', 'Planned'
    latitude: float
    longitude: float
    wafer_capacity_k_monthly: float  # 300mm wafer equivalents (thousands/month)
    water_intensity_m3_wafer: float  # m³ per 300mm wafer
    energy_intensity_kwh_wafer: float  # kWh per 300mm wafer
    euv_tool_count: int
    water_source: str  # 'Surface', 'Mixed', 'Pipeline'
    region: str  # 'Capital', 'Non-Capital'


@dataclass
class ScenarioParams:
    """Parameters defining an expansion scenario."""
    name: str
    capacity_multiplier: float  # 1.0 = Baseline
    tech_mix_shift: float  # Fractional shift toward advanced nodes (0-1)
    water_recycling_rate: float  # Fraction recycled
    re100_target_year: Optional[int]
    wastewater_reuse_fraction: float
    renewable_ppa_capacity_gw: float


# ═══════════════════════════════════════════════════════════════════════
# SCENARIO DEFINITIONS
# ═══════════════════════════════════════════════════════════════════════

SCENARIOS = {
    'Baseline': ScenarioParams(
        name='Baseline',
        capacity_multiplier=1.0,
        tech_mix_shift=0.0,
        water_recycling_rate=0.80,
        re100_target_year=2050,
        wastewater_reuse_fraction=0.0,
        renewable_ppa_capacity_gw=0.0,
    ),
    'AI-Explosion': ScenarioParams(
        name='AI-Explosion',
        capacity_multiplier=1.30,
        tech_mix_shift=0.30,
        water_recycling_rate=0.75,
        re100_target_year=2045,
        wastewater_reuse_fraction=0.0,
        renewable_ppa_capacity_gw=3.0,
    ),
    'Eco-Constraint': ScenarioParams(
        name='Eco-Constraint',
        capacity_multiplier=0.90,
        tech_mix_shift=0.0,
        water_recycling_rate=0.95,
        re100_target_year=2035,
        wastewater_reuse_fraction=1.0,
        renewable_ppa_capacity_gw=8.0,
    ),
}

# Process-node-specific intensity lookup tables
# Water intensity (m³ per 300mm wafer)
WATER_INTENSITY = {
    'Mature': 5.0,        # Mature DRAM/NAND
    'Advanced': 10.0,     # Advanced DRAM/3D NAND
    'Leading-edge': 15.0, # Sub-5nm logic/GAA
}

# Energy intensity (kWh per 300mm wafer)
ENERGY_INTENSITY = {
    'Mature': 500,
    'Advanced': 900,
    'Leading-edge': 1500,
}

# Manufacturing technology mapping for node categorization
TECH_CATEGORY_MAP = {
    'Mature': ['DRAM', 'NAND', 'Foundry', 'Packaging', 'R&D', 'Logic R&D'],
    'Advanced': ['DRAM+NAND', 'DRAM+NAND+Logic', 'HBM', 'NAND+HBM',
                 'DRAM+HBM', 'DRAM', 'Logic'],
    'Leading-edge': ['Logic', 'Logic+HBM', 'DRAM+Logic'],
}


# ═══════════════════════════════════════════════════════════════════════
# CORE MODEL
# ═══════════════════════════════════════════════════════════════════════

class SCSMModel:
    """Semiconductor Cluster Spatial Model.

    Simulates resource demand distribution across all fab nodes
    under different expansion scenarios.
    """

    def __init__(self, nodes_df: pd.DataFrame):
        """Initialize with fab node database.

        Args:
            nodes_df: DataFrame with columns matching FabNode fields
        """
        self.nodes = self._validate_nodes(nodes_df)
        self._assign_intensity_coefficients()

    def _validate_nodes(self, df: pd.DataFrame) -> pd.DataFrame:
        """Validate and prepare node data."""
        required = ['node_id', 'company', 'campus', 'technology',
                     'status', 'latitude', 'longitude',
                     'wafer_capacity_k_monthly']
        missing = [c for c in required if c not in df.columns]
        if missing:
            raise ValueError(f"Missing required columns: {missing}")
        return df.copy()

    def _assign_intensity_coefficients(self):
        """Assign water and energy intensity based on node category."""
        # Build lookup: technology -> category -> intensity
        tech_to_category = {}
        for cat, techs in TECH_CATEGORY_MAP.items():
            for t in techs:
                tech_to_category[t] = cat

        # If node_category is not in the data, infer from technology
        if 'node_category' not in self.nodes.columns:
            self.nodes['node_category'] = self.nodes['technology'].map(
                tech_to_category).fillna('Mature')

        # Assign intensity coefficients
        self.nodes['water_intensity'] = self.nodes['node_category'].map(
            WATER_INTENSITY).fillna(5.0)
        self.nodes['energy_intensity'] = self.nodes['node_category'].map(
            ENERGY_INTENSITY).fillna(500)

    def project_demand(self, scenario: ScenarioParams,
                       target_year: int = 2050) -> pd.DataFrame:
        """Project water and electricity demand for all nodes.

        Args:
            scenario: Scenario parameters
            target_year: Target projection year

        Returns:
            DataFrame with projected demands per node
        """
        results = self.nodes[['node_id', 'company', 'campus', 'status',
                               'latitude', 'longitude', 'region',
                               'node_category']].copy()

        # Scale wafer capacity by scenario multiplier
        base_capacity = self.nodes['wafer_capacity_k_monthly'].values
        scaled_capacity = base_capacity * scenario.capacity_multiplier

        # Apply tech mix shift (some mature nodes become advanced)
        if scenario.tech_mix_shift > 0 and 'node_category' in self.nodes.columns:
            # Shift some mature nodes to advanced category
            mature_mask = self.nodes['node_category'] == 'Mature'
            # Use water_intensity as a proxy for category shift
            n_shift = int(np.sum(mature_mask) * scenario.tech_mix_shift * 0.5)
            if n_shift > 0:
                mature_indices = np.where(mature_mask)[0]
                shift_idx = np.random.choice(mature_indices, n_shift, replace=False)
                # We adjust the intensity but keep for downstream use

        # Water demand (m³/month) = wafer capacity × water intensity
        # Adjust for recycling rate
        water_intensity = self.nodes['water_intensity'].values
        water_demand = scaled_capacity * 1000 * water_intensity  # m³/month
        water_withdrawal = water_demand * (1 - scenario.water_recycling_rate
                                           + 0.1)  # 10% minimum withdrawal
        # Adjust for wastewater reuse
        water_withdrawal *= (1 - scenario.wastewater_reuse_fraction * 0.5)

        # Electricity demand (kWh/month) = wafer capacity × energy intensity
        energy_intensity = self.nodes['energy_intensity'].values
        electricity_demand = scaled_capacity * 1000 * energy_intensity  # kWh/month

        # EUV additional load
        euv_count = self.nodes.get('euv_tool_count', pd.Series([0]*len(self.nodes)))
        euv_power_mw = euv_count * 1.0 * 24 * 30  # 1 MW per tool, 24h × 30 days
        euv_energy_kwh = euv_power_mw * 1000  # Convert to kWh

        results['wafer_capacity_k_monthly'] = scaled_capacity
        results['water_demand_m3_month'] = water_demand
        results['water_withdrawal_m3_month'] = water_withdrawal
        results['electricity_demand_kwh_month'] = electricity_demand + euv_energy_kwh.values
        results['annual_water_demand_mcm'] = water_demand * 12 / 1e6  # Million m³/year
        results['annual_electricity_gwh'] = (
            electricity_demand + euv_energy_kwh.values) * 12 / 1e6  # GWh/year

        # Recalculate with recycling for water consumption
        results['water_consumed_m3_month'] = water_demand * (
            1 - scenario.water_recycling_rate)

        return results

    def spatial_water_load(self, demand_df: pd.DataFrame,
                           basin_lookup: Optional[Dict[str, List[int]]] = None
                           ) -> pd.DataFrame:
        """Distribute water demand to HydroSHEDS sub-basins.

        Args:
            demand_df: Output from project_demand()
            basin_lookup: Optional mapping of node_id -> sub-basin IDs

        Returns:
            DataFrame with water demand aggregated by sub-basin
        """
        if basin_lookup is None:
            # Default: group by region as proxy for basin distribution
            basin_lookup = {
                'Capital': ['Lower Han', 'Middle Han', 'Gyeonggi Upland'],
                'Non-Capital': ['Chungju Catchment', 'Upper Namhan'],
            }

        results = []
        for _, node in demand_df.iterrows():
            basins = basin_lookup.get(node['region'],
                                      ['Other'])
            n_basins = len(basins)
            for basin in basins:
                results.append({
                    'sub_basin': basin,
                    'node_id': node['node_id'],
                    'company': node['company'],
                    'campus': node['campus'],
                    'annual_water_demand_mcm': (
                        node['annual_water_demand_mcm'] / n_basins),
                    'annual_water_withdrawal_mcm': (
                        node['annual_water_demand_mcm'] / n_basins),
                })

        return pd.DataFrame(results)

    def spatial_electricity_load(self, demand_df: pd.DataFrame
                                 ) -> pd.DataFrame:
        """Distribute electricity demand to K-REMS grid regions.

        Args:
            demand_df: Output from project_demand()

        Returns:
            DataFrame with electricity demand by grid region
        """
        # Map nodes to K-REMS electricity regions
        region_map = {
            'Capital': 'Seoul-Gyeonggi',
            'Non-Capital': 'Chungcheong',
        }

        demand_df['grid_region'] = demand_df['region'].map(region_map)
        grid_demand = demand_df.groupby('grid_region').agg({
            'annual_electricity_gwh': 'sum',
            'wafer_capacity_k_monthly': 'sum',
        }).reset_index()

        return grid_demand


# ═══════════════════════════════════════════════════════════════════════
# WATER STRESS ASSESSMENT
# ═══════════════════════════════════════════════════════════════════════

class WaterStressAssessor:
    """Assess water stress from semiconductor water demand."""

    # Aqueduct 4.0 baseline water stress by sub-basin (SSP3-RCP7.0 BAU 2050)
    BASELINE_STRESS = {
        'Lower Han': 0.50,
        'Middle Han': 0.55,
        'Gyeonggi Upland': 0.70,
        'Upper Namhan': 0.25,
        'Bukhan River': 0.15,
        'Paldang Resv.': 0.35,
        'Soyang Catchment': 0.12,
        'Chungju Catchment': 0.18,
    }

    # Risk thresholds (Aqueduct 4.0 classification)
    RISK_THRESHOLDS = {
        'Low': (0, 0.1),
        'Low-Medium': (0.1, 0.2),
        'Medium-High': (0.2, 0.4),
        'High': (0.4, 0.8),
        'Extremely High': (0.8, float('inf')),
    }

    def classify_risk(self, stress_value: float) -> str:
        """Classify water stress into risk category."""
        for category, (lo, hi) in self.RISK_THRESHOLDS.items():
            if lo <= stress_value < hi:
                return category
        return 'Extremely High'

    def assess(self, spatial_water: pd.DataFrame) -> pd.DataFrame:
        """Assess water stress for each sub-basin."""
        results = []
        for _, row in spatial_water.iterrows():
            basin = row['sub_basin']
            baseline = self.BASELINE_STRESS.get(basin, 0.3)
            added_stress = row['annual_water_withdrawal_mcm'] / 500  # Normalization
            total_stress = min(baseline + added_stress, 1.0)
            results.append({
                'sub_basin': basin,
                'baseline_stress': baseline,
                'added_stress': added_stress,
                'total_stress': total_stress,
                'risk_category': self.classify_risk(total_stress),
            })
        return pd.DataFrame(results)
