# Semiconductor Cluster Spatial Model (SCSM)

## Resource requirements and localized sustainability consequences of the semiconductor Mega Cluster expansion in South Korea

This repository contains the source code for the Semiconductor Cluster Spatial Model (SCSM) and all figure generation scripts used in the study:

**"Resource requirements and localized sustainability consequences of the semiconductor Mega Cluster expansion in South Korea"**  
*Submitted to Nature Sustainability*

---

## Repository Structure

```
code/
├── SCSM/                          # Core model
│   └── scsm_model.py              # Semiconductor Cluster Spatial Model
├── figures/                       # Figure generation scripts
│   ├── fig1_framework.py          # Fig 1: Research framework diagram
│   ├── fig2_water_stress.py       # Fig 2: Water stress by risk category
│   ├── fig3_han_river_basin.py    # Fig 3: Han River basin water stress map
│   ├── fig4_electricity.py        # Fig 4: Electricity cost & grid impacts
│   ├── fig5_land_concentration.py # Fig 5: Land use & spatial concentration
│   ├── fig6_shap.py               # Fig 6: XGBoost/SHAP vulnerability analysis
│   └── fig_s1_generation_mix.py   # Fig S1: Generation mix transition
├── data/                          # Input data files (see Data Availability)
│   └── fab_nodes.csv              # SCSM node database (37 fab nodes)
├── shp_reader.py                  # Pure-Python shapefile reader
├── requirements.txt               # Python dependencies
└── CODE_AVAILABILITY.md           # Code availability statement
```

## Dependencies

See `requirements.txt` for full list. Key dependencies:
- Python 3.10+
- NumPy, Pandas, Matplotlib, SciPy
- XGBoost, SHAP (for vulnerability analysis)
- pdf2image, python-docx (for output generation)

## SCSM Model

The core model (`SCSM/scsm_model.py`) implements:

1. **Node-specific resource allocation**: Calculates water and electricity demand per fabrication node based on wafer capacity and process-node-specific intensity coefficients
2. **Spatial load mapping**: Distributes resource demands to geographic units (HydroSHEDS sub-basins for water, K-REMS grid nodes for electricity)
3. **Scenario engine**: Simulates three expansion scenarios (Baseline, AI-Explosion, Eco-Constraint) to 2050

## Figure Generation

Each figure has a dedicated script in `figures/`. To regenerate all figures:

```bash
# Install dependencies
pip install -r requirements.txt

# Run all figure generation
python figures/generate_all.py

# Or run individual figures
python figures/fig2_water_stress.py
python figures/fig3_han_river_basin.py
```

## Data

Input data files are in `data/`. Primary data sources:
- **Aqueduct 4.0**: World Resources Institute (water stress indicators)
- **11th Basic Plan**: Republic of Korea (electricity capacity projections)
- **KOSTAT**: Statistics Korea (employment, population, regional data)
- **OSM**: OpenStreetMap (geographic basemap data)
- **Corporate reports**: Samsung, SK Hynix, TSMC sustainability reports

Full data sources are documented in the paper's Supplementary Data Sources table.

## License

This code is available for research and reproducibility purposes. Please cite the original paper if using this code.

## Contact

[Author information to be added upon publication]
