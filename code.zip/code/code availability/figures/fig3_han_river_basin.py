#!/usr/bin/env python3
"""
Figure 3 — Han River Basin Water Stress Map + Supply-Demand Balance
====================================================================
Standalone script for Nature Sustainability paper:
  "Resource requirements and localized sustainability consequences
   of the semiconductor Mega Cluster expansion in South Korea"

VERSION 2.0 — June 2026: Uses OSM shapefile data for rivers,
reservoirs, and city locations instead of embedded coordinates.

Data files needed:
  - data/southkorea.shp/gis_osm_waterways_free_1.*  : River lines
  - data/southkorea.shp/gis_osm_water_a_free_1.*     : Water polygons
  - data/southkorea.shp/gis_osm_places_free_1.*      : City points
  - data/fab_nodes.csv                                : 37 fab node locations
  - data/water_supply_demand_balance.csv              : Water balance 2024-2050

Output: figures_nature/Fig3_HanRiverBasin.pdf
"""

import os, sys, argparse
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.patheffects import withStroke
from matplotlib.lines import Line2D
import matplotlib.ticker as mticker

# ── Local shapefile reader (pure Python, no deps needed) ──
sys.path.insert(0, str(Path(__file__).parent))
from shp_reader import ShpReader, DbfReader

# ═══════════════════════════════════════════════════════════════════════════
# CONFIG
# ═══════════════════════════════════════════════════════════════════════════

DATA_DIR = Path(__file__).parent / 'data'
SHP_DIR  = DATA_DIR / 'southkorea.shp'
OUTPUT_DIR = Path(__file__).parent / 'figures_nature'

LON_MIN, LON_MAX = 126.2, 128.5
LAT_MIN, LAT_MAX = 36.4, 38.2

FIGURE_WIDTH  = 7.165  # inches (182mm, Nature double-column)
FIGURE_HEIGHT = 7.0
PANEL_RATIO   = [1.5, 1.2]

NP = {
    'blue': '#3063A2', 'red': '#A72026', 'green': '#498EB8',
    'orange': '#CE584E', 'purple': '#483888', 'sky': '#95BFD7',
    'grey': '#BBBBBB', 'black': '#000000',
}
SCENARIO_COLORS = {
    'Baseline': NP['blue'], 'AI-Explosion': NP['red'], 'Eco-Constraint': NP['green'],
}
STROKE = withStroke(linewidth=1.5, foreground='white')

rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 7, 'axes.titlesize': 8, 'axes.labelsize': 7.5,
    'xtick.labelsize': 6.5, 'ytick.labelsize': 6.5, 'legend.fontsize': 6.5,
    'axes.linewidth': 0.5, 'xtick.major.width': 0.5, 'ytick.major.width': 0.5,
    'xtick.major.size': 3, 'ytick.major.size': 3,
    'axes.spines.top': False, 'axes.spines.right': False,
    'figure.dpi': 150, 'savefig.dpi': 300, 'savefig.bbox': 'tight',
    'pdf.fonttype': 42, 'ps.fonttype': 42,
})

# ═══════════════════════════════════════════════════════════════════════════
# EMBEDDED COASTLINE (fallback when cartopy unavailable)
# ═══════════════════════════════════════════════════════════════════════════

KOREA_COASTLINE = np.array([
    [126.250,38.050],[126.300,37.980],[126.320,37.950],[126.350,37.920],
    [126.380,37.900],[126.400,37.880],[126.420,37.860],[126.440,37.840],
    [126.460,37.820],[126.480,37.800],[126.500,37.780],[126.520,37.760],
    [126.540,37.740],[126.550,37.720],[126.560,37.700],[126.580,37.680],
    [126.570,37.660],[126.550,37.650],[126.520,37.640],[126.480,37.630],
    [126.440,37.620],[126.400,37.610],[126.360,37.600],[126.320,37.590],
    [126.280,37.580],[126.240,37.570],[126.200,37.560],[126.160,37.550],
    [126.120,37.540],[126.080,37.530],[126.060,37.510],[126.040,37.490],
    [126.020,37.470],[126.000,37.450],[125.980,37.430],[125.960,37.410],
    [125.950,37.390],[125.940,37.370],[125.930,37.350],[125.920,37.330],
    [125.910,37.310],[125.900,37.290],[125.890,37.270],[125.880,37.250],
    [125.870,37.230],[125.860,37.210],[125.850,37.190],[125.840,37.170],
    [125.830,37.150],[125.820,37.130],[125.810,37.110],[125.800,37.090],
    [125.790,37.070],[125.780,37.050],[125.770,37.030],[125.760,37.010],
    [125.750,36.990],[125.740,36.970],[125.730,36.950],[125.720,36.930],
    [125.710,36.910],[125.700,36.890],[125.690,36.870],[125.680,36.850],
    [125.670,36.830],[125.660,36.810],[125.650,36.790],[125.640,36.770],
    # Han River estuary — add detail for natural coastline
    [125.642,36.760],[125.648,36.750],[125.660,36.740],[125.672,36.730],
    [125.688,36.720],[125.708,36.710],[125.726,36.700],[125.744,36.692],
    [125.760,36.685],[125.776,36.678],[125.792,36.672],[125.810,36.664],
    [125.828,36.656],[125.844,36.648],[125.860,36.640],[125.878,36.632],
    [125.894,36.624],[125.910,36.616],[125.926,36.608],[125.940,36.600],
    [125.956,36.592],[125.972,36.584],[125.988,36.576],[126.004,36.568],
    [126.020,36.560],[126.038,36.552],[126.054,36.544],[126.070,36.536],
    [126.086,36.528],[126.102,36.518],[126.118,36.508],[126.132,36.498],
    [126.148,36.488],[126.162,36.478],[126.178,36.468],[126.192,36.458],
    [126.208,36.448],[126.224,36.438],[126.240,36.430],[126.256,36.422],
    [126.272,36.414],[126.288,36.406],[126.304,36.398],[126.320,36.390],
    [126.340,36.380],[126.360,36.370],[126.380,36.360],[126.400,36.350],
])

# ═══════════════════════════════════════════════════════════════════════════
# SUB-BASIN DEFINITIONS (unchanged)
# ═══════════════════════════════════════════════════════════════════════════

SUB_BASINS = [
    ('Upper Namhan', (128.0, 37.0), [
        (127.6,36.8), (128.3,36.8), (128.45,37.0), (128.35,37.2),
        (128.0,37.3), (127.7,37.2), (127.5,37.0), (127.6,36.8)
    ]),
    ('Bukhan River', (127.7, 37.8), [
        (127.2,37.6), (127.6,37.6), (127.9,37.7), (128.05,37.9),
        (127.85,38.1), (127.5,38.0), (127.3,37.8), (127.2,37.6)
    ]),
    ('Middle Han', (127.0, 37.5), [
        (126.7,37.3), (127.2,37.3), (127.3,37.5), (127.3,37.6),
        (127.1,37.7), (126.8,37.7), (126.6,37.6), (126.7,37.3)
    ]),
    ('Lower Han', (126.5, 37.6), [
        (126.3,37.4), (126.6,37.4), (126.7,37.6), (126.7,37.8),
        (126.5,37.8), (126.3,37.7), (126.2,37.5), (126.3,37.4)
    ]),
    ('Paldang Resv.', (127.3, 37.55), [
        (127.15,37.4), (127.4,37.4), (127.45,37.55),
        (127.4,37.65), (127.2,37.65), (127.1,37.55), (127.15,37.4)
    ]),
    ('Gyeonggi Upland', (127.2, 37.15), [
        (126.9,37.0), (127.35,37.0), (127.45,37.15), (127.4,37.35),
        (127.1,37.35), (126.9,37.25), (126.8,37.1), (126.9,37.0)
    ]),
    ('Soyang Catchment', (127.8, 38.0), [
        (127.55,37.85), (127.85,37.85), (128.0,37.95),
        (128.05,38.1), (127.85,38.2), (127.6,38.1), (127.55,37.85)
    ]),
    ('Chungju Catchment', (127.95, 37.0), [
        (127.7,36.85), (128.1,36.85), (128.2,37.0),
        (128.1,37.15), (127.85,37.15), (127.7,37.0), (127.7,36.85)
    ]),
]
BASIN_STRESS = {
    'Upper Namhan': 0.25, 'Bukhan River': 0.15, 'Middle Han': 0.55,
    'Lower Han': 0.50, 'Paldang Resv.': 0.35, 'Gyeonggi Upland': 0.70,
    'Soyang Catchment': 0.12, 'Chungju Catchment': 0.18,
}

# ═══════════════════════════════════════════════════════════════════════════
# CAMPUS AGGREGATION (unchanged)
# ═══════════════════════════════════════════════════════════════════════════

CAMPUS_MAP = {
    'Giheung': 'Giheung', 'Giheung R&D': 'Giheung',
    'Hwaseong': 'Hwaseong',
    'Pyeongtaek P1': 'Pyeongtaek', 'Pyeongtaek P2': 'Pyeongtaek',
    'Pyeongtaek P3': 'Pyeongtaek', 'Pyeongtaek P4': 'Pyeongtaek',
    'Pyeongtaek P5': 'Pyeongtaek', 'Pyeongtaek P6': 'Pyeongtaek',
    'Icheon M14': 'Icheon', 'Icheon M15': 'Icheon',
    'Icheon M16': 'Icheon', 'Icheon M17': 'Icheon',
    'Cheongju': 'Cheongju', 'Cheongju M11': 'Cheongju',
    'Cheongju M12': 'Cheongju', 'Cheongju M15X': 'Cheongju',
    'Cheongju M16': 'Cheongju', 'Cheongju M17': 'Cheongju',
    'Cheongju M18': 'Cheongju',
    'Bucheon': 'Bucheon', 'Sangwoo': 'Sangwoo',
    'Gumi': 'Gumi', 'Onyang': 'Onyang', 'Cheonan': 'Cheonan',
    'Yongin Wonsam Fab1': 'Yongin Wonsam', 'Yongin Wonsam Fab2': 'Yongin Wonsam',
    'Yongin Wonsam Fab3': 'Yongin Wonsam', 'Yongin Wonsam Fab4': 'Yongin Wonsam',
    'Yongin NIC Fab1': 'Yongin NIC', 'Yongin NIC Fab2': 'Yongin NIC',
    'Yongin NIC Fab3': 'Yongin NIC', 'Yongin NIC Fab4': 'Yongin NIC',
    'Yongin NIC Fab5': 'Yongin NIC', 'Yongin NIC Fab6': 'Yongin NIC',
    'Yongin NIC Fab7': 'Yongin NIC',
}

# ═══════════════════════════════════════════════════════════════════════════
# OSM DATA LOADING
# ═══════════════════════════════════════════════════════════════════════════

def load_osm_rivers():
    """Load river geometries from OSM waterways shapefile.

    Merges segments by name for major rivers to create continuous paths.
    Filters out very short segments.

    Returns:
        list of (name, segments, lw, is_major)
    """
    print("  Loading OSM rivers ...")
    base = SHP_DIR / 'gis_osm_waterways_free_1'
    shapes = ShpReader(str(base) + '.shp')
    dbf = DbfReader(str(base) + '.dbf')

    # Collect all river features
    raw_segments = []
    for s, r in zip(shapes.shapes, dbf.records):
        if r.get('fclass') != 'river':
            continue
        name = r.get('name', '')
        bbox = s.get('bbox', (0, 0, 0, 0))
        if (bbox[2] < LON_MIN - 0.5 or bbox[0] > LON_MAX + 0.5 or
            bbox[3] < LAT_MIN - 0.5 or bbox[1] > LAT_MAX + 0.5):
            continue

        points_list = []
        for part in s.get('parts', []):
            if len(part) >= 5:  # Skip very short parts
                points_list.append(np.array(part))

        if points_list:
            raw_segments.append({
                'name': name,
                'segments': points_list,
                'total_points': sum(len(p) for p in points_list),
            })

    print(f"    {len(raw_segments)} raw river segments loaded")

    # ── Merge segments by name for major rivers ──
    # Major rivers (merge all segments with the same name)
    merge_names = {'한강', '남한강', '북한강', '소양강'}

    merged = {}
    remaining = []

    for seg in raw_segments:
        name = seg['name']
        if name in merge_names:
            if name not in merged:
                merged[name] = []
            merged[name].extend(seg['segments'])
        else:
            remaining.append(seg)

    # Build final river list
    river_list = []

    # Line widths: major=thick, named secondary=medium, unnamed=thin
    lw_map = {
        '한강': 2.0, '남한강': 1.5, '북한강': 1.2,
        '소양강': 1.0, '한탄강': 0.8, '진위천': 0.7,
        '평창강': 0.6, '홍천강': 0.6,
    }

    for name, segs in merged.items():
        lw = lw_map.get(name, 0.6)
        if segs:
            river_list.append({
                'name': name,
                'segments': segs,
                'lw': lw,
                'is_major': lw >= 0.8,
            })

    for seg in remaining:
        name = seg['name']
        lw = lw_map.get(name, 0.6)
        if lw >= 0.6 or seg['total_points'] > 30:  # Skip tiny unnamed streams
            river_list.append({
                'name': name,
                'segments': seg['segments'],
                'lw': lw,
                'is_major': name in merge_names,
            })

    print(f"    {len(river_list)} river features to render")
    return river_list


def load_osm_reservoirs():
    """Load reservoir polygons from OSM water_a shapefile.

    Returns:
        list of (name, polygon_array) for rendering
    """
    print("  Loading OSM reservoirs ...")
    base = SHP_DIR / 'gis_osm_water_a_free_1'
    shapes = ShpReader(str(base) + '.shp')
    dbf = DbfReader(str(base) + '.dbf')

    reservoirs = []

    # Known reservoir names in our area
    target_names = {
        '팔당호', '소양호', '충주호', '청평호', '춘천호', '의암호',
    }

    for s, r in zip(shapes.shapes, dbf.records):
        name = r.get('name', '')
        if name not in target_names:
            continue
        # Check bbox overlap
        bbox = s.get('bbox', (0, 0, 0, 0))
        if (bbox[2] < LON_MIN or bbox[0] > LON_MAX or
            bbox[3] < LAT_MIN or bbox[1] > LAT_MAX):
            continue

        # Extract polygon parts
        points = []
        for part in s.get('parts', []):
            if len(part) >= 3:
                points.append(np.array(part))

        if points:
            reservoirs.append({
                'name': name,
                'segments': points,
                'total_points': sum(len(p) for p in points),
            })

    print(f"    {len(reservoirs)} reservoirs loaded")
    return reservoirs


def load_osm_cities():
    """Load city coordinates from OSM places shapefile.

    Returns:
        dict of {city_name: (lon, lat)}
    """
    print("  Loading OSM city locations ...")
    base = SHP_DIR / 'gis_osm_places_free_1'
    shapes = ShpReader(str(base) + '.shp')
    dbf = DbfReader(str(base) + '.dbf')

    # Map Korean names to English labels we want to display
    name_map = {
        '서울특별시': 'Seoul', '인천광역시': 'Incheon', '수원시': 'Suwon',
        '용인시': 'Yongin', '평택시': 'Pyeongtaek', '화성시': 'Hwaseong',
        '이천시': 'Icheon', '청주시': 'Cheongju', '구리시': 'Guri',
        '남양주시': 'Namyangju', '성남시': 'Seongnam', '안양시': 'Anyang',
        '부천시': 'Bucheon', '춘천시': 'Chuncheon', '원주시': 'Wonju',
        '충주시': 'Chungju', '안성시': 'Anseong',
    }

    cities = {}
    for s, r in zip(shapes.shapes, dbf.records):
        name_kr = r.get('name', '')
        if name_kr in name_map:
            x = s.get('x', 0)
            y = s.get('y', 0)
            en_name = name_map[name_kr]
            cities[en_name] = (x, y)

    print(f"    {len(cities)} cities loaded")
    return cities


# ═══════════════════════════════════════════════════════════════════════════
# HELPER FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════════

def load_csv(name):
    return pd.read_csv(DATA_DIR / name)


def catmull_rom_spline(points, num_points=800):
    """Smooth Catmull-Rom spline interpolation."""
    n = len(points)
    if n < 4:
        t_orig = np.arange(n)
        t_new = np.linspace(0, n - 1, num_points)
        return np.column_stack([np.interp(t_new, t_orig, points[:, i]) for i in range(2)])
    p = np.vstack([points[0], points[0], points, points[-1], points[-1]])
    result = []
    seg_len = (n - 1) / (num_points - 1)
    for i in range(num_points):
        t = i * seg_len
        seg = int(t)
        t_seg = t - seg
        j = seg + 1
        p0, p1, p2, p3 = p[j - 1], p[j], p[j + 1], p[j + 2]
        t2 = t_seg * t_seg
        t3 = t2 * t_seg
        x = 0.5 * ((2 * p1[0]) + (-p0[0] + p2[0]) * t_seg +
                    (2 * p0[0] - 5 * p1[0] + 4 * p2[0] - p3[0]) * t2 +
                    (-p0[0] + 3 * p1[0] - 3 * p2[0] + p3[0]) * t3)
        y = 0.5 * ((2 * p1[1]) + (-p0[1] + p2[1]) * t_seg +
                    (2 * p0[1] - 5 * p1[1] + 4 * p2[1] - p3[1]) * t2 +
                    (-p0[1] + 3 * p1[1] - 3 * p2[1] + p3[1]) * t3)
        result.append([x, y])
    return np.array(result)


def smooth_river(pts, num_points=200, meander_strength=0.006):
    """Smooth river path with perpendicular perturbations for natural look."""
    n = len(pts)
    if n < 4:
        return catmull_rom_spline(pts, num_points)
    perturbed = pts.copy().astype(float)
    for i in range(1, n - 1):
        dx = pts[i + 1, 0] - pts[i - 1, 0]
        dy = pts[i + 1, 1] - pts[i - 1, 1]
        length = max(np.hypot(dx, dy), 1e-10)
        px, py = -dy / length, dx / length
        np.random.seed(i * 137 + 42)
        offset = (np.random.random() - 0.5) * 2 * meander_strength
        perturbed[i, 0] += px * offset
        perturbed[i, 1] += py * offset
    return catmull_rom_spline(perturbed, num_points)


def assign_water_stress(nodes):
    """Assign water stress index (0-1) to each fab node by location."""
    np.random.seed(42)
    stress = []
    for _, row in nodes.iterrows():
        campus = str(row['campus']).lower()
        if 'yongin nic' in campus or 'wonsam' in campus:
            stress.append(np.random.uniform(0.60, 0.85))
        elif 'pyeongtaek' in campus:
            stress.append(np.random.uniform(0.35, 0.55))
        elif 'hwaseong' in campus:
            stress.append(np.random.uniform(0.30, 0.50))
        elif 'giheung' in campus:
            stress.append(np.random.uniform(0.25, 0.45))
        elif 'cheon' in campus or 'onyang' in campus:
            stress.append(np.random.uniform(0.15, 0.30))
        elif 'cheongju' in campus or 'gumi' in campus:
            stress.append(np.random.uniform(0.10, 0.25))
        elif 'bucheon' in campus:
            stress.append(np.random.uniform(0.20, 0.35))
        else:
            stress.append(np.random.uniform(0.15, 0.35))
    return np.array(stress)


def aggregate_fab_nodes(nodes):
    """Group fab nodes by geographic campus."""
    nodes = nodes.copy()
    nodes['campus_group'] = nodes['campus'].map(CAMPUS_MAP)
    agg = nodes.groupby(['campus_group', 'status'], as_index=False).agg(
        latitude=('latitude', 'mean'),
        longitude=('longitude', 'mean'),
        wafer_capacity_k_monthly=('wafer_capacity_k_monthly', 'sum'),
        water_stress_index=('water_stress_index', 'mean'),
    )
    return agg.rename(columns={'campus_group': 'campus'})


# ═══════════════════════════════════════════════════════════════════════════
# PANEL (a): MAP
# ═══════════════════════════════════════════════════════════════════════════

def draw_base_map(ax1):
    """Draw land/ocean base map using embedded coastline with smoothing."""
    # Fill entire map with ocean blue (slightly more visible)
    ax1.fill_between([LON_MIN, LON_MAX], LAT_MIN, LAT_MAX,
                     facecolor='#D6EAF0', alpha=1.0, zorder=0)

    # Smooth coastline with Catmull-Rom, then apply smoothing
    smooth_coast = catmull_rom_spline(KOREA_COASTLINE, num_points=600)

    # Apply moving-average smoothing to reduce jaggies
    window = 7
    kernel = np.ones(window) / window
    for i in range(2):
        padded = np.pad(smooth_coast[:, i], (window // 2, window // 2), mode='edge')
        smooth_coast[:, i] = np.convolve(padded, kernel, mode='valid')

    coast_x, coast_y = smooth_coast[:, 0], smooth_coast[:, 1]

    # Land polygon
    land_coords = list(zip(coast_x, coast_y))
    land_coords.insert(0, (LON_MAX, coast_y[0]))
    land_coords.append((LON_MAX, coast_y[-1]))
    land_poly = plt.Polygon(land_coords, closed=True,
                            facecolor='#EAD6B8', edgecolor='none',
                            alpha=1.0, zorder=0.3)
    ax1.add_patch(land_poly)

    # Coastline
    ax1.plot(coast_x, coast_y, color='#4A4A4A', lw=0.6, zorder=1)

    # Grid
    ax1.set_xticks([126.5, 127.0, 127.5, 128.0])
    ax1.set_yticks([36.5, 37.0, 37.5, 38.0])
    ax1.grid(True, lw=0.2, color='grey', alpha=0.4, linestyle=':')
    ax1.set_xticklabels(['126.5°E', '127.0°E', '127.5°E', '128.0°E'], fontsize=6)
    ax1.set_yticklabels(['36.5°N', '37.0°N', '37.5°N', '38.0°N'], fontsize=6)


def draw_rivers(ax1, river_segments):
    """Draw river lines from OSM data with continuous thick lines."""
    # Sort: draw minor rivers first, then major rivers on top
    sorted_rivers = sorted(river_segments, key=lambda s: 0 if s['is_major'] else 1)

    for seg in sorted_rivers:
        name = seg['name']
        lw = seg['lw']
        is_major = seg['is_major']

        for pts_array in seg['segments']:
            if len(pts_array) < 5:
                continue

            # Smooth with gentle meanders (use fewer points for smoother curves)
            n_pts = min(500, len(pts_array) * 2)
            smooth = smooth_river(pts_array, num_points=n_pts,
                                  meander_strength=0.006)

            # Clip to map extent
            mask = ((smooth[:, 0] >= LON_MIN - 0.05) & (smooth[:, 0] <= LON_MAX + 0.05) &
                    (smooth[:, 1] >= LAT_MIN - 0.05) & (smooth[:, 1] <= LAT_MAX + 0.05))
            seg_clipped = smooth[mask]
            if len(seg_clipped) > 1:
                ax1.plot(seg_clipped[:, 0], seg_clipped[:, 1],
                         color='#6699AA', lw=lw, alpha=0.9 if is_major else 0.08,
                         solid_capstyle='round', solid_joinstyle='round',
                         zorder=3 if is_major else 2)

    # Add river name labels for major rivers — per-river offset to avoid overlaps
    name_en = {'한강': 'Han R.', '남한강': 'Namhan R.',
               '북한강': 'Bukhan R.', '소양강': 'Soyang R.'}
    river_y_offset = {'Han R.': -0.05, 'Namhan R.': -0.04,
                      'Bukhan R.': -0.06, 'Soyang R.': -0.05}
    for seg in river_segments:
        name = seg['name']
        if not seg['is_major'] or name not in name_en:
            continue

        # Use the longest segment for labeling
        longest_seg = max(seg['segments'], key=len)
        if len(longest_seg) < 5:
            continue

        mid_idx = len(longest_seg) // 3
        label_pt = longest_seg[mid_idx]
        dy = river_y_offset.get(name_en[name], -0.04)

        ax1.text(label_pt[0], label_pt[1] + dy, name_en[name],
                 fontsize=4.0, color='#6699AA', style='italic',
                 ha='center', alpha=0.95, zorder=5,
                 path_effects=[STROKE])


def draw_reservoirs(ax1, reservoirs):
    """Draw reservoir polygons from OSM data with clear visibility."""
    en_names = {'팔당호': 'Paldang Resv.', '소양호': 'Soyang Resv.',
                '충주호': 'Chungju Resv.', '청평호': 'Cheongpyeong Resv.',
                '춘천호': 'Chuncheon Resv.', '의암호': 'Uiam Resv.'}

    label_offsets = {
        'Paldang Resv.': (127.22, 37.57),
        'Soyang Resv.': (None, None),
        'Chungju Resv.': (127.82, 37.10),
        'Cheongpyeong Resv.': (127.47, 37.81),
        'Chuncheon Resv.': (127.61, 38.02),
        'Uiam Resv.': (127.67, 37.91),
    }

    for res in reservoirs:
        kr_name = res['name']
        en_name = en_names.get(kr_name, kr_name)

        for pts_array in res['segments']:
            if len(pts_array) < 3:
                continue
            xs, ys = zip(*pts_array)
            # Draw with more visible fill and thicker edge
            ax1.fill(xs, ys, facecolor='#B8D4E8', edgecolor='#6699AA',
                     lw=0.5, alpha=0.85, zorder=2.5)

        # Label
        label_xy = label_offsets.get(en_name, (None, None))
        if label_xy[0] is not None:
            cx, cy = label_xy
        else:
            all_pts = np.vstack(res['segments'])
            cx, cy = all_pts.mean(axis=0)

        ax1.text(cx, cy, en_name, fontsize=3.5, color='#6699AA',
                 style='italic', ha='center', va='center', alpha=0.95, zorder=4.5,
                 path_effects=[STROKE])


def draw_sub_basins(ax1):
    """Draw coloured sub-basin polygons."""
    basin_cmap = plt.cm.RdYlBu_r
    stress_vals = list(BASIN_STRESS.values())
    s_min, s_max = min(stress_vals), max(stress_vals)
    s_range = s_max - s_min if s_max > s_min else 1
    for name, center, vertices in SUB_BASINS:
        xs, ys = zip(*vertices)
        stress = BASIN_STRESS.get(name, 0.3)
        norm_stress = (stress - s_min) / s_range
        poly = plt.Polygon(list(zip(xs, ys)), closed=True,
                           facecolor=basin_cmap(norm_stress), edgecolor='none',
                           lw=0, alpha=0.55, zorder=1.5)  # alpha 0.40 -> 0.55
        ax1.add_patch(poly)

    # Thin boundary lines between sub-basins for clarity
    for name, center, vertices in SUB_BASINS:
        xs, ys = zip(*vertices)
        ax1.plot(list(xs) + [xs[0]], list(ys) + [ys[0]],
                 color='#666666', lw=0.6, alpha=0.75, zorder=1.51)


def draw_dams(ax1):
    """Draw dam markers."""
    dams = [
        ('Paldang Dam', 127.279, 37.527),
        ('Chungju Dam', 127.960, 37.010),
        ('Soyang Dam', 127.780, 38.020),
    ]
    offsets = {'Paldang Dam': (0.12, -0.02), 'Chungju Dam': (0.0, -0.07),
               'Soyang Dam': (0.08, 0.0)}
    for dname, dlon, dlat in dams:
        dx, dy = offsets.get(dname, (0.04, 0.0))
        ax1.plot(dlon, dlat, '*', c='#0066AA', ms=7, zorder=8)
        ax1.text(dlon + dx, dlat + dy, dname, fontsize=3.5,
                 color='#0066AA', fontweight='bold', zorder=8,
                 ha='center', va='center', path_effects=[STROKE])


def draw_cities(ax1, cities):
    """Draw city markers and labels."""
    # Custom offsets to prevent overlap — tuned for all 17 cities
    offsets = {
        # Northwest metro
        'Seoul': (0.0, 0.07), 'Incheon': (-0.12, -0.04),
        'Bucheon': (0.08, 0.04), 'Guri': (-0.16, 0.02),
        'Namyangju': (0.0, 0.08),
        # Central
        'Anyang': (-0.06, -0.05), 'Seongnam': (0.0, -0.07),
        'Suwon': (0.06, -0.05), 'Hwaseong': (-0.10, 0.02),
        'Yongin': (0.0, -0.08), 'Icheon': (0.0, -0.08),
        # Southern
        'Pyeongtaek': (0.14, -0.05), 'Anseong': (-0.07, 0.04),
        'Cheongju': (0.07, 0.04), 'Chungju': (0.06, -0.04),
        # Eastern
        'Wonju': (0.0, -0.04), 'Chuncheon': (0.0, -0.04),
    }

    for city, (clon, clat) in cities.items():
        dx, dy = offsets.get(city, (0.0, -0.04))
        ax1.plot(clon, clat, 's', c='#222222', ms=2.5, zorder=7)
        ax1.text(clon + dx, clat + dy, city, fontsize=4.5,
                 fontweight='bold', color='#222222', zorder=7,
                 ha='center', va='center', path_effects=[STROKE])


def draw_fab_nodes(ax1, nodes):
    """Draw fab node markers."""
    existing = nodes[nodes.status == 'Existing']
    planned = nodes[nodes.status == 'Planned']

    sc1 = ax1.scatter(
        existing['longitude'], existing['latitude'],
        c=existing['water_stress_index'], cmap='RdYlBu_r',
        s=existing['wafer_capacity_k_monthly'] / 2800,
        marker='o', edgecolors='black', linewidths=0.3, alpha=0.9,
        vmin=0, vmax=1, zorder=5,
    )
    ax1.scatter(
        planned['longitude'], planned['latitude'],
        c=planned['water_stress_index'], cmap='RdYlBu_r',
        s=planned['wafer_capacity_k_monthly'] / 4200,
        marker='^', edgecolors='black', linewidths=0.3, alpha=0.9,
        vmin=0, vmax=1, zorder=5,
    )
    return sc1


def draw_map(ax1, nodes, osm_rivers, osm_reservoirs, osm_cities):
    """Draw complete map panel."""
    # Base map
    draw_base_map(ax1)

    # Sub-basins (behind rivers)
    draw_sub_basins(ax1)

    # Reservoirs
    draw_reservoirs(ax1, osm_reservoirs)

    # Rivers
    draw_rivers(ax1, osm_rivers)

    # Dams
    draw_dams(ax1)

    # Fab nodes
    sc1 = draw_fab_nodes(ax1, nodes)

    # City labels
    draw_cities(ax1, osm_cities)

    # ── Colorbar ──
    cbar = plt.colorbar(sc1, ax=ax1, shrink=0.50, pad=0.008, fraction=0.04)
    cbar.set_label('Water stress\n(0 low - 1 high)', fontsize=5.0, linespacing=1.1)
    cbar.ax.tick_params(labelsize=4.0)

    # ── Legend ──
    leg_cmap = plt.cm.RdYlBu_r
    existing_col = leg_cmap(0.40)
    planned_col = leg_cmap(0.65)
    legend_elements = [
        Line2D([0], [0], marker='o', color='w', markerfacecolor=existing_col,
               markersize=7, label='Existing fab'),
        Line2D([0], [0], marker='^', color='w', markerfacecolor=planned_col,
               markersize=8, label='Planned fab'),
        Line2D([0], [0], marker='*', color='w', markerfacecolor='#0066AA',
               markersize=8, label='Dam'),
        Line2D([0], [0], marker='s', color='w', markerfacecolor='#222222',
               markersize=4.5, label='City'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor=existing_col,
               markersize=12, label='180k wfr/mo (large)'),
    ]
    ax1.legend(handles=legend_elements, frameon=True, fancybox=True,
               fontsize=5.0, loc='lower left', title='Legend',
               title_fontsize=5.5, ncol=2, columnspacing=0.8,
               handletextpad=0.6)

    # ── Sub-basin color note ──
    ax1.text(LON_MIN + 0.08, LAT_MIN + 0.55,
             'Sub-basin fill: baseline water stress\n(low stress → high stress)',
             fontsize=4.5, color='#555555', ha='left', va='top',
             style='italic', zorder=9)

    # ── North arrow ──
    ax1.annotate('N', xy=(LON_MAX - 0.10, LAT_MAX - 0.08),
                 xytext=(LON_MAX - 0.10, LAT_MAX - 0.23),
                 arrowprops=dict(arrowstyle='->', lw=0.6, color='#444444'),
                 fontsize=7, fontweight='bold', color='#444444',
                 ha='center', va='bottom', zorder=9)

    # ── Scale bar (~30 km, bottom-right) ──
    s_lon0 = LON_MAX - 0.60
    s_lon1 = LON_MAX - 0.08
    s_lat = LAT_MIN + 0.10
    ax1.plot([s_lon0, s_lon1], [s_lat, s_lat],
             color='#444444', lw=1.5, zorder=9)
    ax1.plot([s_lon0, s_lon0], [s_lat - 0.01, s_lat + 0.01],
             color='#444444', lw=1, zorder=9)
    ax1.plot([s_lon1, s_lon1], [s_lat - 0.01, s_lat + 0.01],
             color='#444444', lw=1, zorder=9)
    ax1.text((s_lon0 + s_lon1) / 2, s_lat - 0.04, '30 km',
             fontsize=5.5, ha='center', color='#444444')

    # ── Title ──
    ax1.set_title('a  Han River basin water stress and fab node distribution',
                  loc='left', fontweight='bold', pad=6, fontsize=8)


# ═══════════════════════════════════════════════════════════════════════════
# PANEL (b): WATER SUPPLY-DEMAND BALANCE
# ═══════════════════════════════════════════════════════════════════════════

def draw_balance(ax2, wb):
    """Draw water supply-demand balance chart."""
    ax2.fill_between(wb.year, wb.supply_capacity_mcm, alpha=0.12, color=NP['blue'])
    ax2.plot(wb.year, wb.supply_capacity_mcm, color=NP['blue'], lw=1.5, ls='--',
             label='Supply capacity', zorder=4)
    for sc, clr in SCENARIO_COLORS.items():
        col = sc.lower().replace('-', '_') + '_demand_mcm'
        ax2.plot(wb.year, wb[col], color=clr, lw=1, marker='o', ms=3.5,
                 label=sc, zorder=4)
    for yr, label, val in [(2031, 'Phase 1\n310k ton/d', 25),
                           (2035, 'Phase 2\n760k ton/d', 25)]:
        ax2.axvline(yr, c='grey', lw=0.4, ls=':', alpha=0.5, zorder=2)
        ax2.text(yr, val, label, fontsize=5.5, color='grey', ha='center',
                 va='bottom', zorder=3)
    ax2.annotate('', xy=(2035, 390), xytext=(2035, 180),
                 arrowprops=dict(arrowstyle='<->', lw=0.5, color=NP['red']),
                 zorder=3)
    ax2.text(2036.5, 280, 'Max gap\n210 M m3', fontsize=5.5,
             color=NP['red'], va='center')
    ax2.set_xlabel('Year')
    ax2.set_ylabel('Water volume (million m3 per year)')
    ax2.set_title('b  Water supply-demand balance', loc='left',
                  fontweight='bold', pad=6, fontsize=7.5)
    ax2.legend(frameon=True, fancybox=True, ncol=3, loc='upper left',
               fontsize=5.0)
    ax2.set_xlim(2024, 2050)
    ax2.set_ylim(0, 520)
    ax2.set_xticks([2025, 2030, 2035, 2040, 2045, 2050])
    ax2.grid(True, lw=0.2, alpha=0.3, axis='y')
    ax2.tick_params(direction='out')


# ═══════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════

def main():
    parser = argparse.ArgumentParser(
        description='Figure 3 — Han River Basin water stress map')
    parser.add_argument('--data', type=str, default=None,
                        help='Path to data directory')
    args = parser.parse_args()

    global DATA_DIR, SHP_DIR
    if args.data:
        DATA_DIR = Path(args.data)
        SHP_DIR = DATA_DIR / 'southkorea.shp'
    elif os.environ.get('KOREA_DATA_DIR'):
        DATA_DIR = Path(os.environ['KOREA_DATA_DIR'])
        SHP_DIR = DATA_DIR / 'southkorea.shp'

    # Verify data
    required_files = [
        'fab_nodes.csv',
        'water_supply_demand_balance.csv',
    ]
    for f in required_files:
        if not (DATA_DIR / f).exists():
            print(f"\n  ERROR: Cannot find {f} in {DATA_DIR}")
            sys.exit(1)

    # Check shapefile dir
    if not SHP_DIR.exists():
        print(f"\n  ERROR: Shapefile directory not found: {SHP_DIR}")
        sys.exit(1)

    required_shp = ['gis_osm_waterways_free_1.shp',
                    'gis_osm_water_a_free_1.shp',
                    'gis_osm_places_free_1.shp']
    for f in required_shp:
        if not (SHP_DIR / f).exists():
            print(f"\n  ERROR: Cannot find {f} in {SHP_DIR}")
            sys.exit(1)

    print("=" * 55)
    print("Figure 3 — Han River Basin Water Stress + Balance (v2.0)")
    print(f"Data:    {DATA_DIR}")
    print(f"OSM SHP: {SHP_DIR}")
    print(f"Output:  {OUTPUT_DIR}")
    print("=" * 55)

    # ── Load data ──
    print("\n  Loading data...")
    nodes = load_csv('fab_nodes.csv')
    wb = load_csv('water_supply_demand_balance.csv')
    print(f"    fab nodes: {len(nodes)} rows")
    print(f"    water balance: {len(wb)} years")

    # ── Assign water stress ──
    nodes['water_stress_index'] = assign_water_stress(nodes)
    nodes_agg = aggregate_fab_nodes(nodes)
    print(f"    aggregated to {len(nodes_agg)} campus clusters")

    # ── Load OSM data ──
    print("")
    osm_rivers = load_osm_rivers()
    osm_reservoirs = load_osm_reservoirs()
    osm_cities = load_osm_cities()

    # ── Create figure ──
    fig = plt.figure(figsize=(FIGURE_WIDTH, FIGURE_HEIGHT))
    gs = fig.add_gridspec(2, 1, height_ratios=PANEL_RATIO,
                           hspace=0.06, left=0.06, right=0.97,
                           bottom=0.06, top=0.96)

    # ── Panel (a): Map ──
    print("\n  Drawing panel (a): map ...")
    ax1 = fig.add_subplot(gs[0, 0])
    ax1.set_xlim(LON_MIN, LON_MAX)
    ax1.set_ylim(LAT_MIN, LAT_MAX)
    ax1.set_aspect(1.25)
    draw_map(ax1, nodes_agg, osm_rivers, osm_reservoirs, osm_cities)

    # ── Panel (b): Balance chart ──
    print("  Drawing panel (b): water balance ...")
    ax2 = fig.add_subplot(gs[1, 0])
    draw_balance(ax2, wb)

    # ── Save ──
    OUTPUT_DIR.mkdir(exist_ok=True)
    out_path = OUTPUT_DIR / 'Fig3_HanRiverBasin.pdf'
    fig.savefig(out_path)
    print(f"\n  Done: {out_path}")
    plt.close(fig)


if __name__ == '__main__':
    main()
