#!/usr/bin/env python3
"""
SCSM Geographic Database Map — Fab Node Distribution Across South Korea
========================================================================
For Nature Sustainability paper:
  "Resource requirements and localized sustainability consequences
   of the semiconductor Mega Cluster expansion in South Korea"

Shows all 37 fab nodes (20 existing + 17 planned) across the K-Semiconductor Belt,
using OSM base data (admin boundary, water bodies, rivers, cities).

Output: figures_nature/Fig_SCSM_GeographicDB.pdf
"""

import sys
from pathlib import Path

import numpy as np
import pandas as pd

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
from matplotlib.patheffects import withStroke
from matplotlib.lines import Line2D

sys.path.insert(0, str(Path(__file__).parent))
from shp_reader import ShpReader, DbfReader

# ── Paths ──
SCRIPT_DIR = Path(__file__).parent.resolve()
DATA_DIR = SCRIPT_DIR / 'data'
SHP_DIR  = DATA_DIR / 'southkorea.shp'
OUTPUT_DIR = SCRIPT_DIR / 'figures_nature'
OUTPUT_DIR.mkdir(exist_ok=True)

# ── Map extent ──
LON_MIN, LON_MAX = 126.0, 129.2
LAT_MIN, LAT_MAX = 35.8, 38.3

# ── Color palette ──
C = {
    'crimson':    '#A72026',
    'brick':      '#CE584E',
    'peach':      '#EC9F83',
    'light_blue': '#95BFD7',
    'steel_blue': '#498EB8',
    'navy':       '#3063A2',
    'purple':     '#483888',
    'grey':       '#BBBBBB',
    'dark_grey':  '#888888',
    'black':      '#000000',
    'white':      '#FFFFFF',
}

COMPANY_COLORS = {
    'Samsung':    C['navy'],
    'SK Hynix':   C['crimson'],
    'DB HiTek':   C['steel_blue'],
    'Key Foundry': C['purple'],
    'MagnaChip':  C['dark_grey'],
}

TECH_COLORS = {
    'DRAM':       C['navy'],
    'NAND':       C['steel_blue'],
    'Logic':      C['crimson'],
    'Foundry':    C['purple'],
    'Packaging':  C['dark_grey'],
    'HBM':        C['peach'],
    'R&D':        C['light_blue'],
}

STROKE = withStroke(linewidth=1.5, foreground='white')

rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 7,
    'axes.linewidth': 0.5,
    'figure.dpi': 150,
    'savefig.dpi': 300,
    'pdf.fonttype': 42,
})

# ═══════════════════════════════════════════════════════════════════════
# OSM DATA LOADING
# ═══════════════════════════════════════════════════════════════════════

def load_osm_admin_boundary():
    """Load the South Korea national boundary from OSM admin areas."""
    print("  Loading OSM admin boundary...")
    base = SHP_DIR / 'gis_osm_adminareas_a_free_1'
    shapes = ShpReader(str(base) + '.shp')
    dbf = DbfReader(str(base) + '.dbf')

    for s, r in zip(shapes.shapes, dbf.records):
        if r.get('fclass') == 'national' and r.get('name') == '대한민국':
            # Get the largest polygon part
            parts = s.get('parts', [])
            if parts:
                max_part = max(parts, key=lambda p: len(p))
                print(f"    boundary loaded: {len(max_part)} vertices")
                return np.array(max_part)
    print("    WARNING: national boundary not found, using coast")
    return None


def load_osm_water():
    """Load water polygons, filtering to significant ones only."""
    print("  Loading OSM water polygons...")
    base = SHP_DIR / 'gis_osm_water_a_free_1'
    shapes = ShpReader(str(base) + '.shp')
    dbf = DbfReader(str(base) + '.dbf')
    waters = []
    for s, r in zip(shapes.shapes, dbf.records):
        bbox = s.get('bbox', (0, 0, 0, 0))
        if (bbox[2] < LON_MIN - 0.5 or bbox[0] > LON_MAX + 0.5 or
            bbox[3] < LAT_MIN - 0.5 or bbox[1] > LAT_MAX + 0.5):
            continue
        # Filter: only include relatively large water bodies
        area = (bbox[2] - bbox[0]) * (bbox[3] - bbox[1])
        if area < 0.002:  # skip tiny ponds
            continue
        fclass = r.get('fclass', '')
        name = r.get('name', '')
        # Keep: known reservoirs, rivers, large lakes
        if fclass in ('reservoir', 'lake', 'river', 'basin') or name:
            for part in s.get('parts', []):
                if len(part) >= 10:
                    waters.append(np.array(part))
    print(f"    {len(waters)} water bodies")
    return waters


def load_osm_rivers():
    """Load major rivers only."""
    print("  Loading OSM rivers...")
    base = SHP_DIR / 'gis_osm_waterways_free_1'
    shapes = ShpReader(str(base) + '.shp')
    dbf = DbfReader(str(base) + '.dbf')
    rivers = []
    for s, r in zip(shapes.shapes, dbf.records):
        if r.get('fclass') != 'river':
            continue
        bbox = s.get('bbox', (0, 0, 0, 0))
        if (bbox[2] < LON_MIN - 0.5 or bbox[0] > LON_MAX + 0.5 or
            bbox[3] < LAT_MIN - 0.5 or bbox[1] > LAT_MAX + 0.5):
            continue
        for part in s.get('parts', []):
            # Only longer river segments
            if len(part) >= 20:
                rivers.append(np.array(part))
    print(f"    {len(rivers)} river segments")
    return rivers


def load_osm_cities():
    """Load major city locations."""
    print("  Loading OSM cities...")
    base = SHP_DIR / 'gis_osm_places_free_1'
    shapes = ShpReader(str(base) + '.shp')
    dbf = DbfReader(str(base) + '.dbf')

    name_map = {
        '서울특별시': 'Seoul', '인천광역시': 'Incheon',
        '수원시': 'Suwon', '용인시': 'Yongin',
        '평택시': 'Pyeongtaek', '화성시': 'Hwaseong',
        '이천시': 'Icheon', '청주시': 'Cheongju',
        '성남시': 'Seongnam', '구미시': 'Gumi',
        '춘천시': 'Chuncheon',
    }
    cities = {}
    for s, r in zip(shapes.shapes, dbf.records):
        name_kr = r.get('name', '')
        if name_kr in name_map:
            cities[name_map[name_kr]] = (s.get('x', 0), s.get('y', 0))
    print(f"    {len(cities)} cities loaded")
    return cities


# ═══════════════════════════════════════════════════════════════════════
# DRAWING FUNCTIONS
# ═══════════════════════════════════════════════════════════════════════

def draw_base_map(ax, boundary):
    """Draw base map with OSM admin boundary, ocean, and grid."""
    # Ocean fill
    ax.fill_between([LON_MIN, LON_MAX], LAT_MIN, LAT_MAX,
                    facecolor='#D6EAF0', alpha=1.0, zorder=0)

    if boundary is not None:
        # Land polygon from OSM admin boundary
        land_poly = plt.Polygon(boundary, closed=True,
                                facecolor='#F0ECD8', edgecolor='none',
                                alpha=1.0, zorder=0.3)
        ax.add_patch(land_poly)
        # Coastline
        ax.plot(boundary[:, 0], boundary[:, 1],
                color='#4A4A4A', lw=0.6, zorder=1)
    else:
        print("    WARNING: no OSM boundary available")
        # Fallback: fill entire extent as land
        ax.fill_between([LON_MIN, LON_MAX], LAT_MIN, LAT_MAX,
                        facecolor='#F0ECD8', alpha=1.0, zorder=0.3)

    # Grid
    ax.set_xticks([126.5, 127.0, 127.5, 128.0, 128.5, 129.0])
    ax.set_yticks([36.0, 36.5, 37.0, 37.5, 38.0])
    ax.grid(True, lw=0.2, color='grey', alpha=0.4, linestyle=':')
    ax.set_xticklabels(['126.5°E', '127.0°E', '127.5°E', '128.0°E', '128.5°E', '129.0°E'],
                       fontsize=5.5)
    ax.set_yticklabels(['36.0°N', '36.5°N', '37.0°N', '37.5°N', '38.0°N'],
                       fontsize=5.5)


def draw_cities(ax, cities, boundary=None):
    """Draw city markers with carefully tuned offsets to avoid overlap."""
    # Only show major cities to reduce clutter
    major = ['Seoul', 'Incheon', 'Suwon', 'Cheongju', 'Gumi', 'Chuncheon']

    offsets = {
        'Seoul':     (0.00, 0.09),
        'Incheon':   (-0.18, -0.02),
        'Suwon':     (0.10, -0.04),
        'Cheongju':  (0.00, -0.10),
        'Gumi':      (0.14, -0.04),
        'Chuncheon': (0.00, -0.06),
    }

    for city, (clon, clat) in cities.items():
        if city not in major:
            continue
        dx, dy = offsets.get(city, (0.0, -0.05))
        ax.plot(clon, clat, 's', c='#555555', ms=3, zorder=7)
        ax.text(clon + dx, clat + dy, city, fontsize=5,
                fontweight='bold', color='#333333', zorder=8,
                ha='center', va='center', path_effects=[STROKE])


def draw_fab_nodes(ax, nodes):
    """Draw fab nodes by company with size = capacity."""
    existing = nodes[nodes.status == 'Existing']
    planned = nodes[nodes.status == 'Planned']
    max_cap = nodes['wafer_capacity_k_monthly'].max()

    # Existing nodes
    sc_ex = ax.scatter(
        existing['longitude'], existing['latitude'],
        c=existing['company'].map(COMPANY_COLORS),
        s=existing['wafer_capacity_k_monthly'] / max_cap * 100 + 30,
        marker='o', edgecolors='white', linewidths=0.4, alpha=0.90, zorder=6
    )

    # Planned nodes
    sc_pl = ax.scatter(
        planned['longitude'], planned['latitude'],
        c=planned['company'].map(COMPANY_COLORS),
        s=planned['wafer_capacity_k_monthly'] / max_cap * 100 + 30,
        marker='^', edgecolors='white', linewidths=0.4, alpha=0.85, zorder=6
    )

    # Cluster labels with leader lines to avoid overlapping icons
    clusters = [
        ('Pyeongtaek\n(6 fabs)', 37.030, 127.055, 0.00, -0.13),
        ('Giheung R&D', 37.229, 127.085, 0.00, -0.11),
        ('Hwaseong', 37.219, 127.069, 0.14, 0.00),
        ('Icheon\n(4 fabs)', 37.248, 127.478, 0.00, -0.12),
        ('Yongin NIC\n(7 planned)', 37.110, 127.265, 0.00, -0.13),
        ('Yongin Wonsam\n(4 fabs)', 37.153, 127.303, 0.16, 0.02),
        ('Cheongju\n(6 fabs)', 36.595, 127.444, 0.00, -0.13),
        ('Onyang/Cheonan', 36.790, 127.080, -0.14, 0.02),
        ('Gumi', 36.120, 128.340, 0.00, -0.10),
    ]

    for name, clat, clon, dx, dy in clusters:
        # Leader line from label to cluster center
        label_x = clon + dx
        label_y = clat + dy
        ax.plot([label_x, clon], [label_y, clat],
                color=C['navy'], lw=0.3, alpha=0.4, zorder=5)
        ax.text(label_x, label_y, name, fontsize=4.5,
                color=C['navy'], fontweight='bold',
                ha='center', va='center',
                path_effects=[STROKE], zorder=9)

    return sc_ex, sc_pl


def draw_water_bodies(ax, water_polys):
    """Draw OSM water polygons."""
    for poly_pts in water_polys:
        ax.fill(poly_pts[:, 0], poly_pts[:, 1],
                facecolor='#B8D4E8', edgecolor='#6699AA',
                lw=0.2, alpha=0.7, zorder=2)


def draw_rivers(ax, river_segments):
    """Draw OSM rivers."""
    for seg in river_segments:
        if len(seg) > 1:
            ax.plot(seg[:, 0], seg[:, 1], color='#6699AA',
                    lw=0.3, alpha=0.4, zorder=2)


# ═══════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════

def main():
    print("=" * 55)
    print("SCSM Geographic Database Map")
    print(f"Output: {OUTPUT_DIR}")
    print("=" * 55)

    # ── Load data ──
    nodes = pd.read_csv(DATA_DIR / 'fab_nodes.csv')
    print(f"\n  Fab nodes: {len(nodes)} ({len(nodes[nodes.status=='Existing'])} existing, "
          f"{len(nodes[nodes.status=='Planned'])} planned)")

    # ── Load OSM data ──
    boundary = load_osm_admin_boundary()
    water_bodies = load_osm_water()
    river_segments = load_osm_rivers()
    osm_cities = load_osm_cities()

    # ── Create figure ──
    fig, ax = plt.subplots(figsize=(7.165, 7.5))
    ax.set_xlim(LON_MIN, LON_MAX)
    ax.set_ylim(LAT_MIN, LAT_MAX)
    ax.set_aspect(1.25)

    print("\n  Drawing base map...")
    draw_base_map(ax, boundary)

    print("  Drawing water bodies...")
    draw_water_bodies(ax, water_bodies)

    print("  Drawing rivers...")
    draw_rivers(ax, river_segments)

    print("  Drawing fab nodes...")
    sc_existing, sc_planned = draw_fab_nodes(ax, nodes)

    print("  Drawing cities...")
    draw_cities(ax, osm_cities, boundary)

    # ── Legend ──
    legend_elements = [
        Line2D([0], [0], marker='o', color='w', markerfacecolor=C['navy'],
               markersize=7, label='Samsung'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor=C['crimson'],
               markersize=7, label='SK Hynix'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor=C['steel_blue'],
               markersize=7, label='DB HiTek'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor=C['purple'],
               markersize=7, label='Other foundry'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor='black',
               markersize=7, label='Existing', markeredgecolor='white', markeredgewidth=0.5),
        Line2D([0], [0], marker='^', color='w', markerfacecolor='black',
               markersize=7, label='Planned', markeredgecolor='white', markeredgewidth=0.5),
    ]

    leg = ax.legend(handles=legend_elements, frameon=True, fancybox=True,
                    fontsize=5.0, loc='lower left', ncol=2, columnspacing=0.8,
                    handletextpad=0.4, borderpad=0.3)
    leg.get_frame().set_linewidth(0.3)
    leg.get_frame().set_edgecolor(C['grey'])

    # ── Title ──
    ax.set_title('SCSM Geographic Database — Semiconductor Fab Node Distribution',
                 fontsize=8, fontweight='bold', color=C['navy'], pad=4, loc='left')

    # ── Statistics box ──
    n_total = len(nodes)
    n_ex = len(nodes[nodes.status == 'Existing'])
    n_pl = len(nodes[nodes.status == 'Planned'])
    n_cap = len(nodes[nodes.region == 'Capital'])
    n_non = len(nodes[nodes.region == 'Non-Capital'])
    tot_cap = nodes['wafer_capacity_k_monthly'].sum()

    stats_text = (
        f'Total: {n_total} fab nodes ({n_ex} existing + {n_pl} planned)\n'
        f'Capital region: {n_cap} nodes  |  Non-capital: {n_non} nodes\n'
        f'Total wafer capacity: {tot_cap/1000:.1f}M 300mm-equiv./month'
    )

    ax.text(LON_MAX - 0.15, LAT_MAX - 0.18, stats_text, fontsize=4.5,
            color=C['white'], ha='right', va='top',
            bbox=dict(facecolor=C['navy'], alpha=0.85, boxstyle='round,pad=0.3',
                      edgecolor='none'),
            zorder=10)

    # ── Scale bar on the RIGHT side ──
    scale_lon = LON_MAX - 0.60  # x position
    scale_lat = LAT_MIN + 0.15   # y position
    scale_deg = 0.55  # ~50 km at 37°N

    # Horizontal bar
    ax.plot([scale_lon, scale_lon + scale_deg], [scale_lat, scale_lat],
            'k-', lw=1.5, zorder=10)
    # Left tick
    ax.plot([scale_lon, scale_lon], [scale_lat - 0.025, scale_lat + 0.025],
            'k-', lw=1.0, zorder=10)
    # Right tick
    ax.plot([scale_lon + scale_deg, scale_lon + scale_deg],
            [scale_lat - 0.025, scale_lat + 0.025], 'k-', lw=1.0, zorder=10)
    # Label
    ax.text(scale_lon + scale_deg / 2, scale_lat - 0.07, '50 km',
            fontsize=5.5, ha='center', va='top', fontweight='bold', zorder=10)

    # ── Inset: Korean Peninsula overview ──
    ax_inset = fig.add_axes([0.72, 0.72, 0.22, 0.22])

    # Inset extent (slightly wider Korea view)
    ins_lon_min, ins_lon_max = 124.0, 130.5
    ins_lat_min, ins_lat_max = 34.0, 38.5
    ax_inset.set_xlim(ins_lon_min, ins_lon_max)
    ax_inset.set_ylim(ins_lat_min, ins_lat_max)
    ax_inset.set_aspect(1.1)
    ax_inset.axis('off')

    # Ocean background
    ax_inset.fill_between([ins_lon_min, ins_lon_max],
                          ins_lat_min, ins_lat_max,
                          facecolor='#D6EAF0', zorder=0)

    # Draw South Korea land using the OSM boundary (clipped to inset extent)
    if boundary is not None:
        mask = ((boundary[:, 0] >= ins_lon_min) & (boundary[:, 0] <= ins_lon_max) &
                (boundary[:, 1] >= ins_lat_min) & (boundary[:, 1] <= ins_lat_max))
        if np.any(mask):
            ax_inset.fill(boundary[:, 0], boundary[:, 1],
                         facecolor='#EAD6B8', edgecolor='#4A4A4A',
                         lw=0.5, zorder=1)

    # Red rectangle showing main map extent
    rect = plt.Rectangle((LON_MIN, LAT_MIN), LON_MAX - LON_MIN, LAT_MAX - LAT_MIN,
                          facecolor='none', edgecolor=C['crimson'], lw=1.2,
                          linestyle='-', zorder=2)
    ax_inset.add_patch(rect)

    # Label the inset
    ax_inset.text(ins_lon_min + 0.2, ins_lat_max - 0.2, 'S. Korea',
                  fontsize=6, color='#555555', ha='left', va='top', fontweight='bold',
                  path_effects=[STROKE])
    ax_inset.text(LON_MIN + 0.02, LAT_MAX - 0.02, 'Main extent',
                  fontsize=4.5, color=C['crimson'], ha='left', va='top',
                  fontweight='bold', path_effects=[STROKE])

    # ── Save ──
    OUTPUT_DIR.mkdir(exist_ok=True)
    out_path = OUTPUT_DIR / 'Fig_SCSM_GeographicDB.pdf'
    fig.savefig(out_path, dpi=300, bbox_inches='tight')
    print(f"\n  Done: {out_path}  ({out_path.stat().st_size / 1024:.0f} KB)")
    plt.close(fig)


if __name__ == '__main__':
    main()
