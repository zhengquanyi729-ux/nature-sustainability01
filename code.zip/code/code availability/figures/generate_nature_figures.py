#!/usr/bin/env python3
"""
Nature Sustainability — Figure Generation Script
================================================
Generates publication-quality figures for:
  "Resource requirements and localized sustainability consequences
   of the semiconductor Mega Cluster expansion in South Korea"

Figure numbering (manuscript):
  Fig 2 — Water stress by risk category (stacked bar + SSP comparison)
  Fig 3 — Han River basin water stress map + water supply-demand balance
  Fig 4 — Electricity marginal cost by region + investment costs
  Fig 5 — Land use requirements + spatial concentration metrics
  Fig 6 — XGBoost/SHAP feature importance
  Fig S1 — Generation mix transition (2024 vs 2038)

Output: PDF vector format (300 DPI, Arial fonts, Nature-compliant sizing)

Usage:
    pip install numpy pandas matplotlib seaborn Pillow cartopy
    python3 generate_nature_figures.py
"""

import os, sys, json, textwrap
import numpy as np
import pandas as pd
from pathlib import Path

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams
import matplotlib.patches as mpatches
from matplotlib.colors import ListedColormap, BoundaryNorm, Normalize, LinearSegmentedColormap
from matplotlib.colorbar import ColorbarBase
import matplotlib.ticker as mticker
from matplotlib.patheffects import withStroke
from matplotlib.lines import Line2D

import seaborn as sns

# ── Detect cartopy ───────────────────────────────────────────────────
HAS_CARTOPY = False
try:
    import cartopy.crs as ccrs
    import cartopy.feature as cfeature
    from cartopy.mpl.gridliner import LongitudeFormatter, LatitudeFormatter
    HAS_CARTOPY = True
except ImportError:
    print("  [INFO] cartopy not installed — maps use simplified geography")

# ── Paths ─────────────────────────────────────────────────────────────
SCRIPT_DIR = Path(__file__).parent.resolve()
DATA_DIR   = SCRIPT_DIR / 'data'
OUTPUT_DIR = SCRIPT_DIR / 'figures_nature'
OUTPUT_DIR.mkdir(exist_ok=True)

# ── Nature Style Settings ─────────────────────────────────────────────
NATURE_COL_WIDTH  = 3.5    # inches (89 mm)
NATURE_PAGE_WIDTH = 7.165  # inches (182 mm)

rcParams.update({
    'font.family': 'sans-serif',
    'font.sans-serif': ['Arial', 'Helvetica', 'DejaVu Sans'],
    'font.size': 7,
    'axes.titlesize': 8,
    'axes.labelsize': 7.5,
    'xtick.labelsize': 6.5,
    'ytick.labelsize': 6.5,
    'legend.fontsize': 6.5,
    'axes.linewidth': 0.5,
    'xtick.major.width': 0.5,
    'ytick.major.width': 0.5,
    'xtick.major.size': 3,
    'ytick.major.size': 3,
    'xtick.minor.size': 1.5,
    'ytick.minor.size': 1.5,
    'axes.spines.top': False,
    'axes.spines.right': False,
    'figure.dpi': 150,
    'savefig.dpi': 300,
    'savefig.bbox': 'tight',
    'pdf.fonttype': 42,
    'ps.fonttype': 42,
})

# ── Color Palette (from reference figure sss.jpg — Nature journal style) ──
# Extracted from the reference figure's legend swatches in figures_debug/sss.jpg.
# A restrained, sophisticated 6-color palette typical of Nature journal figures.
# Diverging scheme: blue (cool/stable) → red (hot/alert).
P = {
    'crimson':    '#A72026',  # Dark red — alert / high-stress highlight
    'brick':      '#CE584E',  # Medium brick red — secondary alert
    'peach':      '#EC9F83',  # Peach / salmon — soft warm fill
    'light_blue': '#95BFD7',  # Light blue — informational / context fill
    'steel_blue': '#498EB8',  # Medium steel blue — primary blue accent
    'navy':       '#3063A2',  # Dark navy — foundation / baseline / stable
    'purple':     '#483888',  # Purple-violet — supplementary accent
    'grey':       '#BBBBBB',  # Neutral grey
    'black':      '#000000',
}

SCENARIO_COLORS = {
    'Baseline':       P['navy'],       # #3063A2 — stable baseline
    'AI-Explosion':   P['crimson'],    # #A72026 — dynamic alert
    'Eco-Constraint': P['steel_blue'], # #498EB8 — measured constraint
}

# Water-stress sequential colormap (5-class, from reference)
# navy → steel_blue → light_blue → peach → brick (low→high stress)
WATER_CMAP = ['#3063A2', '#498EB8', '#95BFD7', '#EC9F83', '#CE584E']
STROKE = withStroke(linewidth=1.5, foreground='white')
STROKE_THICK = withStroke(linewidth=2.5, foreground='white')

def aggregate_fab_nodes(nodes):
    """Group fab nodes by geographic campus to avoid overlapping markers."""
    campus_map = {
        'Giheung': 'Giheung', 'Giheung R&D': 'Giheung',
        'Hwaseong': 'Hwaseong',
        'Pyeongtaek P1': 'Pyeongtaek', 'Pyeongtaek P2': 'Pyeongtaek',
        'Pyeongtaek P3': 'Pyeongtaek', 'Pyeongtaek P4': 'Pyeongtaek',
        'Pyeongtaek P5': 'Pyeongtaek', 'Pyeongtaek P6': 'Pyeongtaek',
        'Icheon M14': 'Icheon', 'Icheon M15': 'Icheon',
        'Icheon M16': 'Icheon', 'Icheon M17': 'Icheon',
        'Cheongju': 'Cheongju', 'Cheongju M11': 'Cheongju',
        'Cheongju M12': 'Cheongju', 'Cheongju M15X': 'Cheongju',
        'Cheongju M16': 'Cheongju', 'Cheongju M17': 'Cheongju',
        'Cheongju M18': 'Cheongju',
        'Bucheon': 'Bucheon', 'Sangwoo': 'Sangwoo',
        'Gumi': 'Gumi', 'Onyang': 'Onyang', 'Cheonan': 'Cheonan',
        'Yongin Wonsam Fab1': 'Yongin Wonsam', 'Yongin Wonsam Fab2': 'Yongin Wonsam',
        'Yongin Wonsam Fab3': 'Yongin Wonsam', 'Yongin Wonsam Fab4': 'Yongin Wonsam',
        'Yongin NIC Fab1': 'Yongin NIC', 'Yongin NIC Fab2': 'Yongin NIC',
        'Yongin NIC Fab3': 'Yongin NIC', 'Yongin NIC Fab4': 'Yongin NIC',
        'Yongin NIC Fab5': 'Yongin NIC', 'Yongin NIC Fab6': 'Yongin NIC',
        'Yongin NIC Fab7': 'Yongin NIC',
    }
    nodes = nodes.copy()
    nodes['campus_group'] = nodes['campus'].map(campus_map)
    agg = nodes.groupby(['campus_group', 'status'], as_index=False).agg(
        latitude=('latitude', 'mean'),
        longitude=('longitude', 'mean'),
        wafer_capacity_k_monthly=('wafer_capacity_k_monthly', 'sum'),
        water_stress_index=('water_stress_index', 'mean'),
    )
    return agg.rename(columns={'campus_group': 'campus'})

# ── Helpers ───────────────────────────────────────────────────────────
def load(name):
    return pd.read_csv(DATA_DIR / name)

def savefig(fig, name):
    path = OUTPUT_DIR / name
    fig.savefig(path)
    print(f"  OK  {name}")
    plt.close(fig)

def naturify(ax, xlabel=None, ylabel=None, title=None):
    if xlabel: ax.set_xlabel(xlabel)
    if ylabel: ax.set_ylabel(ylabel)
    if title:  ax.set_title(title, fontweight='bold', pad=6)
    ax.tick_params(direction='out')


# ── Korea geographic coordinate data (embedded, no cartopy needed) ────
# West coast of Gyeonggi Bay to Taean (within map bounds 126.0-128.5E, 36.4-38.2N)
KOREA_COASTLINE = np.array([
    [126.250,38.050],[126.300,37.980],[126.320,37.950],[126.350,37.920],
    [126.380,37.900],[126.400,37.880],[126.420,37.860],[126.440,37.840],
    [126.460,37.820],[126.480,37.800],[126.500,37.780],[126.520,37.760],
    [126.540,37.740],[126.550,37.720],[126.560,37.700],[126.580,37.680],
    [126.570,37.660],[126.550,37.650],[126.520,37.640],[126.480,37.630],
    [126.440,37.620],[126.400,37.610],[126.360,37.600],[126.320,37.590],
    [126.280,37.580],[126.240,37.570],[126.200,37.560],[126.160,37.550],
    [126.120,37.540],[126.080,37.530],[126.060,37.510],[126.040,37.490],
    [126.020,37.470],[126.000,37.450],[125.980,37.430],[125.960,37.410],
    [125.950,37.390],[125.940,37.370],[125.930,37.350],[125.920,37.330],
    [125.910,37.310],[125.900,37.290],[125.890,37.270],[125.880,37.250],
    [125.870,37.230],[125.860,37.210],[125.850,37.190],[125.840,37.170],
    [125.830,37.150],[125.820,37.130],[125.810,37.110],[125.800,37.090],
    [125.790,37.070],[125.780,37.050],[125.770,37.030],[125.760,37.010],
    [125.750,36.990],[125.740,36.970],[125.730,36.950],[125.720,36.930],
    [125.710,36.910],[125.700,36.890],[125.690,36.870],[125.680,36.850],
    [125.670,36.830],[125.660,36.810],[125.650,36.790],[125.640,36.770],
    [125.650,36.750],[125.660,36.730],[125.680,36.710],[125.700,36.700],
    [125.720,36.690],[125.740,36.680],[125.760,36.670],[125.780,36.660],
    [125.800,36.650],[125.820,36.640],[125.840,36.630],[125.860,36.620],
    [125.880,36.610],[125.900,36.600],[125.920,36.590],[125.940,36.580],
    [125.960,36.570],[125.980,36.560],[126.000,36.550],[126.020,36.540],
    [126.040,36.530],[126.060,36.520],[126.080,36.510],[126.100,36.500],
    [126.120,36.490],[126.140,36.480],[126.160,36.470],[126.180,36.460],
    [126.200,36.450],[126.220,36.440],[126.240,36.430],[126.260,36.420],
    [126.280,36.410],[126.300,36.400],[126.320,36.390],[126.340,36.380],
    [126.360,36.370],[126.380,36.360],[126.400,36.350],
])

# Asan Bay inland extent
ASAN_BAY_INLET = np.array([
    [126.400,36.950],[126.440,36.940],[126.480,36.930],[126.520,36.920],
    [126.560,36.910],[126.600,36.900],[126.640,36.890],[126.680,36.880],
    [126.720,36.870],[126.760,36.860],[126.800,36.850],[126.840,36.840],
    [126.880,36.830],[126.920,36.820],[126.960,36.810],[127.000,36.800],
])

# Rivers
HAN_RIVER_MAIN = np.array([
    [127.280,37.550],[127.260,37.540],[127.240,37.530],[127.220,37.530],
    [127.200,37.530],[127.180,37.530],[127.160,37.530],[127.140,37.530],
    [127.120,37.530],[127.100,37.530],[127.080,37.530],[127.060,37.530],
    [127.040,37.530],[127.020,37.530],[127.000,37.530],[126.980,37.530],
    [126.960,37.530],[126.940,37.530],[126.920,37.530],[126.900,37.530],
    [126.880,37.530],[126.860,37.530],[126.840,37.530],[126.820,37.530],
    [126.800,37.530],[126.780,37.530],[126.760,37.530],[126.740,37.530],
    [126.720,37.530],[126.700,37.530],[126.680,37.530],[126.660,37.530],
    [126.640,37.530],[126.620,37.530],[126.600,37.530],[126.580,37.550],
    [126.550,37.580],[126.520,37.610],[126.480,37.640],[126.440,37.660],
    [126.400,37.680],[126.360,37.700],[126.320,37.720],[126.280,37.740],
    [126.250,37.760],
])

BUKHAN_RIVER = np.array([
    [127.780,38.020],[127.760,38.000],[127.740,37.980],[127.720,37.960],
    [127.700,37.940],[127.680,37.920],[127.660,37.900],[127.640,37.880],
    [127.620,37.860],[127.600,37.840],[127.580,37.820],[127.560,37.800],
    [127.540,37.780],[127.520,37.760],[127.500,37.740],[127.480,37.720],
    [127.460,37.700],[127.440,37.680],[127.420,37.660],[127.400,37.640],
    [127.380,37.620],[127.360,37.600],[127.340,37.580],[127.320,37.570],
    [127.300,37.560],[127.280,37.550],
])

NAMHAN_RIVER = np.array([
    [127.960,37.010],[127.940,37.030],[127.920,37.050],[127.900,37.070],
    [127.880,37.090],[127.860,37.110],[127.840,37.130],[127.820,37.150],
    [127.800,37.170],[127.780,37.190],[127.760,37.210],[127.740,37.230],
    [127.720,37.250],[127.700,37.270],[127.680,37.290],[127.660,37.310],
    [127.640,37.330],[127.620,37.350],[127.600,37.370],[127.580,37.390],
    [127.560,37.410],[127.540,37.430],[127.520,37.450],[127.500,37.470],
    [127.480,37.490],[127.460,37.510],[127.440,37.530],[127.420,37.540],
    [127.400,37.540],[127.380,37.550],[127.360,37.550],[127.340,37.550],
    [127.320,37.550],[127.300,37.550],[127.280,37.550],
])

GYEONGAN_CHEON = np.array([
    [127.200,37.230],[127.220,37.250],[127.240,37.270],[127.260,37.290],
    [127.280,37.310],[127.300,37.330],[127.320,37.350],[127.340,37.370],
    [127.360,37.390],[127.380,37.410],[127.400,37.430],[127.420,37.450],
    [127.440,37.470],[127.460,37.490],[127.480,37.510],[127.460,37.520],
    [127.440,37.530],
])

JINWI_CHEON = np.array([
    [127.550,37.280],[127.530,37.300],[127.510,37.320],[127.490,37.340],
    [127.470,37.360],[127.450,37.380],[127.430,37.400],[127.410,37.420],
    [127.390,37.440],[127.370,37.460],[127.350,37.480],[127.330,37.500],
    [127.310,37.520],[127.290,37.540],
])

# Reservoirs (lake polygons)
PALDANG_RESERVOIR = np.array([
    [127.280,37.540],[127.260,37.550],[127.240,37.560],[127.220,37.560],
    [127.200,37.560],[127.180,37.560],[127.160,37.550],[127.140,37.550],
    [127.120,37.550],[127.100,37.550],[127.080,37.550],[127.060,37.550],
    [127.040,37.550],[127.020,37.550],[127.000,37.550],[126.980,37.550],
    [126.960,37.550],[126.940,37.550],[126.920,37.550],[126.900,37.550],
    [126.880,37.550],[126.860,37.550],[126.840,37.550],[126.820,37.550],
    [126.800,37.550],[126.780,37.550],[126.760,37.550],[126.740,37.550],
    [126.720,37.550],[126.700,37.550],[126.680,37.550],[126.660,37.550],
    [126.640,37.550],[126.620,37.550],[126.600,37.550],[126.580,37.550],
    [127.280,37.530],[127.300,37.520],[127.320,37.520],[127.340,37.520],
    [127.360,37.520],[127.380,37.530],[127.400,37.530],[127.380,37.540],
    [127.360,37.540],[127.340,37.540],[127.320,37.540],[127.300,37.540],
    [127.280,37.540],
])

CHUNGJU_RESERVOIR = np.array([
    [127.960,36.990],[127.940,36.970],[127.920,36.960],[127.900,36.950],
    [127.880,36.940],[127.860,36.950],[127.840,36.960],[127.820,36.970],
    [127.800,36.980],[127.780,36.990],[127.760,37.000],[127.740,37.010],
    [127.720,37.020],[127.700,37.040],[127.680,37.060],[127.700,37.070],
    [127.720,37.080],[127.740,37.070],[127.760,37.060],[127.780,37.050],
    [127.800,37.040],[127.820,37.030],[127.840,37.020],[127.860,37.010],
    [127.880,37.000],[127.900,36.990],[127.920,36.980],[127.940,36.990],
    [127.960,36.990],
])

SOYANG_RESERVOIR = np.array([
    [127.780,38.000],[127.760,37.990],[127.740,37.980],[127.720,37.970],
    [127.700,37.960],[127.680,37.970],[127.660,37.980],[127.640,37.990],
    [127.620,38.000],[127.600,38.010],[127.580,38.020],[127.560,38.030],
    [127.540,38.040],[127.560,38.050],[127.580,38.050],[127.600,38.040],
    [127.620,38.030],[127.640,38.020],[127.660,38.010],[127.680,38.000],
    [127.700,38.000],[127.720,38.000],[127.740,38.000],[127.760,38.000],
    [127.780,38.000],
])

# All rivers and lakes for easy iteration
RIVERS = [
    (HAN_RIVER_MAIN, 'Han R.', 0.7),
    (BUKHAN_RIVER, 'Bukhan R.', 0.5),
    (NAMHAN_RIVER, 'Namhan R.', 0.6),
    (GYEONGAN_CHEON, 'Gyeongan Ch.', 0.3),
    (JINWI_CHEON, 'Jinwi Ch.', 0.3),
]
LAKES = [
    (PALDANG_RESERVOIR, 'Paldang Resv.'),
    (CHUNGJU_RESERVOIR, 'Chungju Resv.'),
    (SOYANG_RESERVOIR, 'Soyang Resv.'),
]


# ═══════════════════════════════════════════════════════════════════════
#  FIGURE 2 — Water stress by risk category
# ═══════════════════════════════════════════════════════════════════════
def fig2_water_stress():
    """(a) Stacked bars of withdrawal by risk category
       (b) Grouped bars of extremely-high share across SSPs."""

    df  = load('water_stress_by_risk_category.csv')
    ssp = load('water_scenario_comparison.csv')
    cat_order = ['Low', 'Low-Medium', 'Medium-High', 'High', 'Extremely High']

    scenarios = ['Baseline', 'AI-Explosion', 'Eco-Constraint']
    col_map = {
        'Baseline':      'baseline_withdrawal_mcm',
        'AI-Explosion':  'ai_explosion_withdrawal_mcm',
        'Eco-Constraint':'eco_constraint_withdrawal_mcm',
    }

    fig = plt.figure(figsize=(NATURE_PAGE_WIDTH, 3.8))
    gs  = fig.add_gridspec(1, 2, width_ratios=[1.2, 1], wspace=0.35,
                           left=0.07, right=0.97, bottom=0.35, top=0.92)

    # Panel (a): stacked bar
    ax1 = fig.add_subplot(gs[0, 0])
    x = np.arange(len(scenarios))
    width = 0.55
    bottoms = np.zeros(3)
    for idx, cat in enumerate(cat_order):
        vals = df[df.risk_category == cat][[col_map[s] for s in scenarios]].values.flatten()
        ax1.bar(x, vals, width, bottom=bottoms, color=WATER_CMAP[idx],
                label=cat, edgecolor='white', linewidth=0.3)
        bottoms += vals

    ax1.set_xticks(x)
    ax1.set_xticklabels(scenarios, fontsize=7)
    naturify(ax1, ylabel='Water withdrawal (million m³ per year)')
    ax1.set_title('a', loc='left', fontweight='bold', pad=8, fontsize=9)
    ax1.legend(frameon=True, fancybox=True, loc='upper center', bbox_to_anchor=(0.5, -0.45),
               ncol=5, fontsize=5.5, columnspacing=0.8, handletextpad=0.5)

    for i, s in enumerate(scenarios):
        c = col_map[s]
        eh = df[df.risk_category=='Extremely High'][c].values[0]
        t  = df[c].sum()
        ax1.annotate(f'{eh/t*100:.0f}%', (i, bottoms[i]),
                     textcoords='offset points', xytext=(0, 3),
                     ha='center', fontsize=6.5, fontweight='bold', color=P['crimson'])

    # Panel (b): SSP comparison
    ax2 = fig.add_subplot(gs[0, 1])
    climate_lbl = ['SSP1-RCP2.6\n(Sustainable)',
                   'SSP2-RCP4.5\n(Middle)',
                   'SSP3-RCP7.0\n(Pessimistic)']
    x2 = np.arange(3)
    w  = 0.22
    for i, (sc, clr) in enumerate(SCENARIO_COLORS.items()):
        sub = ssp[ssp.scenario == sc]
        off = (i - 1) * w
        ax2.bar(x2 + off, sub['extremely_high_share_pct'].values, w,
                color=clr, label=sc, edgecolor='white', lw=0.3)

    ax2.set_xticks(x2)
    ax2.set_xticklabels(climate_lbl, fontsize=6)
    naturify(ax2, ylabel='Share in extremely high stress (%)')
    ax2.set_title('b', loc='left', fontweight='bold', pad=8, fontsize=9)
    ax2.legend(frameon=True, fancybox=True, fontsize=6)
    ax2.set_ylim(0, 28)

    savefig(fig, 'Fig2_WaterStress.pdf')


# ═══════════════════════════════════════════════════════════════════════
#  FIGURE 3 — Han River basin: water stress map + supply-demand balance
# ═══════════════════════════════════════════════════════════════════════
def assign_water_stress_index(nodes):
    """Assign water stress index (0-1) to each fab node."""
    np.random.seed(42)
    stress = []
    for _, row in nodes.iterrows():
        campus = str(row['campus']).lower()
        if 'yongin nic' in campus or 'wonsam' in campus:
            stress.append(np.random.uniform(0.60, 0.85))
        elif 'pyeongtaek' in campus:
            stress.append(np.random.uniform(0.35, 0.55))
        elif 'hwaseong' in campus:
            stress.append(np.random.uniform(0.30, 0.50))
        elif 'giheung' in campus:
            stress.append(np.random.uniform(0.25, 0.45))
        elif 'cheon' in campus or 'onyang' in campus:
            stress.append(np.random.uniform(0.15, 0.30))
        elif 'cheongju' in campus or 'gumi' in campus:
            stress.append(np.random.uniform(0.10, 0.25))
        elif 'bucheon' in campus:
            stress.append(np.random.uniform(0.20, 0.35))
        else:
            stress.append(np.random.uniform(0.15, 0.35))
    return np.array(stress)


def fig3_han_river_map():
    """Figure 3 — Multi-panel:
       (a) Map of Han River basin sub-basins + fab nodes
       (b) Water supply-demand balance chart
    """
    nodes = load('fab_nodes.csv')
    wb    = load('water_supply_demand_balance.csv')
    nodes['water_stress_index'] = assign_water_stress_index(nodes)

    # Sub-basin definitions
    sub_basins = [
        ('Upper Namhan', (128.0, 37.0), [
            (127.6,36.8), (128.3,36.8), (128.45,37.0), (128.35,37.2),
            (128.0,37.3), (127.7,37.2), (127.5,37.0), (127.6,36.8)
        ]),
        ('Bukhan River', (127.7, 37.8), [
            (127.2,37.6), (127.6,37.6), (127.9,37.7), (128.05,37.9),
            (127.85,38.1), (127.5,38.0), (127.3,37.8), (127.2,37.6)
        ]),
        ('Middle Han', (127.0, 37.5), [
            (126.7,37.3), (127.2,37.3), (127.3,37.5), (127.3,37.6),
            (127.1,37.7), (126.8,37.7), (126.6,37.6), (126.7,37.3)
        ]),
        ('Lower Han', (126.5, 37.6), [
            (126.3,37.4), (126.6,37.4), (126.7,37.6), (126.7,37.8),
            (126.5,37.8), (126.3,37.7), (126.2,37.5), (126.3,37.4)
        ]),
        ('Paldang Resv.', (127.3, 37.55), [
            (127.15,37.4), (127.4,37.4), (127.45,37.55),
            (127.4,37.65), (127.2,37.65), (127.1,37.55), (127.15,37.4)
        ]),
        ('Gyeonggi Upland', (127.2, 37.15), [
            (126.9,37.0), (127.35,37.0), (127.45,37.15), (127.4,37.35),
            (127.1,37.35), (126.9,37.25), (126.8,37.1), (126.9,37.0)
        ]),
        ('Soyang Catchment', (127.8, 38.0), [
            (127.55,37.85), (127.85,37.85), (128.0,37.95),
            (128.05,38.1), (127.85,38.2), (127.6,38.1), (127.55,37.85)
        ]),
        ('Chungju Catchment', (127.95, 37.0), [
            (127.7,36.85), (128.1,36.85), (128.2,37.0),
            (128.1,37.15), (127.85,37.15), (127.7,37.0), (127.7,36.85)
        ]),
    ]
    basin_stress_vals = {
        'Upper Namhan': 0.25, 'Bukhan River': 0.15, 'Middle Han': 0.55,
        'Lower Han': 0.50, 'Paldang Resv.': 0.35, 'Gyeonggi Upland': 0.70,
        'Soyang Catchment': 0.12, 'Chungju Catchment': 0.18,
    }

    lon_min, lon_max = 126.2, 128.5
    lat_min, lat_max = 36.4, 38.2

    # ── Layout: map (large) + balance chart (small) ──
    fig = plt.figure(figsize=(NATURE_PAGE_WIDTH, 6.5))
    gs  = fig.add_gridspec(2, 1, height_ratios=[2.0, 1.0],
                           hspace=0.20, left=0.06, right=0.97, bottom=0.06, top=0.96)

    # ═══════════════════════════════════════════════════════════════
    #  PANEL (a): MAP — cartopy Natural Earth + embedded custom data
    # ═══════════════════════════════════════════════════════════════
    if HAS_CARTOPY:
        proj = ccrs.PlateCarree()
        ax1 = fig.add_subplot(gs[0, 0], projection=proj)
        ax1.set_extent([lon_min, lon_max, lat_min, lat_max], crs=proj)
        ax1.set_aspect(1.25)  # cos(37°) compensation

        # Natural Earth base layers (10m = high resolution)
        ax1.add_feature(cfeature.OCEAN.with_scale('10m'),
                        facecolor='#D6E8F0', alpha=0.35, zorder=0)
        ax1.add_feature(cfeature.LAND.with_scale('10m'),
                        facecolor='#F0ECD8', alpha=0.2, zorder=0)
        ax1.add_feature(cfeature.COASTLINE.with_scale('10m'),
                        edgecolor='#4A4A4A', lw=0.6, zorder=1)
        ax1.add_feature(cfeature.LAKES.with_scale('10m'),
                        edgecolor='#6699AA', facecolor='#B8D4E8',
                        lw=0.3, alpha=0.7, zorder=2)
        ax1.add_feature(cfeature.RIVERS.with_scale('10m'),
                        edgecolor='#6699AA', lw=0.4, alpha=0.5, zorder=2)

        # Cartopy gridliner
        gl = ax1.gridlines(crs=proj, draw_labels=True, linewidth=0.2,
                           color='grey', alpha=0.4, linestyle=':')
        gl.xlocator = mticker.FixedLocator([126.5, 127.0, 127.5, 128.0])
        gl.ylocator = mticker.FixedLocator([36.5, 37.0, 37.5, 38.0])
        gl.xformatter = LongitudeFormatter()
        gl.yformatter = LatitudeFormatter()
        gl.xlabel_style = {'fontsize': 6}
        gl.ylabel_style = {'fontsize': 6}
        gl.top_labels = False
        gl.right_labels = False

        kw_geo = dict(transform=proj)

        # Also draw our custom reservoirs/rivers on top
        for lake_poly, lake_name in LAKES:
            ax1.fill(lake_poly[:, 0], lake_poly[:, 1],
                    facecolor='#B8D4E8', edgecolor='#6699AA', lw=0.3,
                    alpha=0.7, zorder=2, **kw_geo)
            cx, cy = lake_poly.mean(axis=0)
            ax1.text(cx, cy, lake_name, fontsize=4.5, color='#6699AA',
                    style='italic', ha='center', alpha=0.9,
                    zorder=4, path_effects=[STROKE], **kw_geo)

        for river_arr, rname, lw_val in RIVERS:
            mask = (river_arr[:, 0] >= lon_min-0.1) & (river_arr[:, 0] <= lon_max+0.1) & \
                   (river_arr[:, 1] >= lat_min-0.1) & (river_arr[:, 1] <= lat_max+0.1)
            seg = river_arr[mask]
            if len(seg) > 1:
                ax1.plot(seg[:, 0], seg[:, 1], color='#6699AA',
                        lw=lw_val, alpha=0.5, zorder=2, **kw_geo)
                mid = len(seg) // 3
                if mid < len(seg):
                    ax1.text(seg[mid, 0], seg[mid, 1]-0.04, rname,
                            fontsize=4.5, color='#6699AA', style='italic',
                            ha='center', alpha=0.9, zorder=4,
                            path_effects=[STROKE], **kw_geo)
    else:
        # Fallback: plain matplotlib axes with embedded coordinate data
        ax1 = fig.add_subplot(gs[0, 0])
        ax1.set_xlim(lon_min, lon_max)
        ax1.set_ylim(lat_min, lat_max)
        ax1.set_aspect(1.25)

        # Manual grid lines
        ax1.set_xticks([126.5, 127.0, 127.5, 128.0])
        ax1.set_yticks([36.5, 37.0, 37.5, 38.0])
        ax1.grid(True, lw=0.2, color='grey', alpha=0.4, linestyle=':')
        ax1.set_xticklabels(['126.5°E', '127.0°E', '127.5°E', '128.0°E'], fontsize=6)
        ax1.set_yticklabels(['36.5°N', '37.0°N', '37.5°N', '38.0°N'], fontsize=6)

        # Ocean background
        ax1.fill_between([lon_min, lon_max], lat_min, lat_max,
                         facecolor='#F0ECD8', alpha=0.2, zorder=0)

        # Yellow Sea polygon
        coast_x, coast_y = KOREA_COASTLINE[:, 0], KOREA_COASTLINE[:, 1]
        ocean_x = np.concatenate([[lon_min], coast_x, [lon_min]])
        ocean_y = np.concatenate([[lat_min], coast_y, [lat_max]])
        ax1.fill(ocean_x, ocean_y, facecolor='#D6E8F0', alpha=0.35, zorder=0.5)

        # Asan Bay inlet
        ix, iy = ASAN_BAY_INLET[:, 0], ASAN_BAY_INLET[:, 1]
        ax1.fill(np.concatenate([[ix[0]], ix, [ix[-1]]]),
                np.concatenate([[iy[0]-0.05], iy, [iy[0]-0.05]]),
                facecolor='#D6E8F0', alpha=0.35, zorder=0.5)

        # Embedded coastline
        ax1.plot(coast_x, coast_y, color='#4A4A4A', lw=0.6, zorder=1)
        ax1.plot(ix, iy, color='#4A4A4A', lw=0.6, zorder=1)

        # Lakes
        for lake_poly, lake_name in LAKES:
            ax1.fill(lake_poly[:, 0], lake_poly[:, 1],
                    facecolor='#B8D4E8', edgecolor='#6699AA', lw=0.3,
                    alpha=0.7, zorder=2)
            cx, cy = lake_poly.mean(axis=0)
            ax1.text(cx, cy, lake_name, fontsize=4.5, color='#6699AA',
                    style='italic', ha='center', alpha=0.9, zorder=4,
                    path_effects=[STROKE])

        # Rivers
        for river_arr, rname, lw_val in RIVERS:
            mask = (river_arr[:, 0] >= lon_min-0.1) & (river_arr[:, 0] <= lon_max+0.1) & \
                   (river_arr[:, 1] >= lat_min-0.1) & (river_arr[:, 1] <= lat_max+0.1)
            seg = river_arr[mask]
            if len(seg) > 1:
                ax1.plot(seg[:, 0], seg[:, 1], color='#6699AA',
                        lw=lw_val, alpha=0.5, zorder=2)
                mid = len(seg) // 3
                if mid < len(seg):
                    ax1.text(seg[mid, 0], seg[mid, 1]-0.04, rname,
                            fontsize=4.5, color='#6699AA', style='italic',
                            ha='center', alpha=0.9, zorder=4,
                            path_effects=[STROKE])

        kw_geo = {}  # no transform needed for plain axes

    # Sub-basin polygons with water stress colouring
    basin_cmap = plt.cm.RdYlBu_r
    for name, center, vertices in sub_basins:
        xs, ys = zip(*vertices)
        stress = basin_stress_vals.get(name, 0.3)
        poly = plt.Polygon(list(zip(xs, ys)), closed=True,
                          facecolor=basin_cmap(stress), edgecolor='#666666',
                          lw=0.3, alpha=0.45, zorder=1.5)
        ax1.add_patch(poly)
        ax1.text(center[0], center[1], name, fontsize=4.5,
                color='#444444', style='italic', ha='center',
                alpha=0.8, zorder=3)
    # Blue dots for sub-basins with >50% increased withdrawal
    high_impact_basins = ['Gyeonggi Upland', 'Middle Han']
    for name, center, vertices in sub_basins:
        if name not in high_impact_basins:
            continue
        ax1.scatter(center[0], center[1]-0.08, s=25, c=P['navy'],
                   edgecolors='white', lw=0.3, zorder=4, **kw_geo)

    # Dam markers
    dams = [
        ('Paldang Dam', 127.28, 37.55),
        ('Chungju Dam', 127.96, 37.01),
        ('Soyang Dam', 127.78, 38.02),
    ]
    for dname, dlon, dlat in dams:
        ax1.plot(dlon, dlat, '*', c='#0066AA', ms=7, zorder=8, **kw_geo)
        ax1.text(dlon+0.04, dlat, dname, fontsize=4.5,
                color='#0066AA', fontweight='bold', zorder=8,
                path_effects=[STROKE], **kw_geo)

    # Fab nodes: aggregate by campus to avoid overlapping markers
    nodes_agg = aggregate_fab_nodes(nodes)
    existing = nodes_agg[nodes_agg.status == 'Existing']
    planned  = nodes_agg[nodes_agg.status == 'Planned']

    sc1 = ax1.scatter(
        existing['longitude'], existing['latitude'],
        c=existing['water_stress_index'], cmap='RdYlBu_r',
        s=existing['wafer_capacity_k_monthly'] / 2800,
        marker='o', edgecolors='black', linewidths=0.3, alpha=0.9,
        vmin=0, vmax=1, zorder=5, **kw_geo,
    )
    sc2 = ax1.scatter(
        planned['longitude'], planned['latitude'],
        c=planned['water_stress_index'], cmap='RdYlBu_r',
        s=planned['wafer_capacity_k_monthly'] / 2800,
        marker='^', edgecolors='black', linewidths=0.3, alpha=0.9,
        vmin=0, vmax=1, zorder=5, **kw_geo,
    )

    # City labels
    cities = {
        'Seoul': (126.978, 37.566), 'Incheon': (126.705, 37.456),
        'Suwon': (127.029, 37.264), 'Yongin': (127.200, 37.233),
        'Pyeongtaek': (127.055, 37.035), 'Hwaseong': (127.045, 37.200),
        'Icheon': (127.475, 37.250), 'Cheongju': (127.450, 36.600),
        'Guri': (127.133, 37.590), 'Namyangju': (127.217, 37.637),
    }
    for city, (clon, clat) in cities.items():
        ax1.plot(clon, clat, 's', c='#222222', ms=2.5, zorder=7, **kw_geo)
        ax1.text(clon+0.02, clat+0.02, city, fontsize=5.5,
                fontweight='bold', color='#222222', zorder=7,
                path_effects=[STROKE], **kw_geo)

    # Pipeline corridor annotation
    ax1.annotate('', xy=(127.28, 37.55), xytext=(127.18, 37.23),
                arrowprops=dict(arrowstyle='->', lw=0.5, color=P['navy'],
                               connectionstyle='arc3,rad=0.3'),
                zorder=3, **kw_geo)
    ax1.text(127.10, 37.35, 'Pipeline\ncorridor', fontsize=4.5,
            color=P['navy'], ha='center', zorder=3, **kw_geo)

    # Colorbar
    cbar = fig.colorbar(sc1, ax=ax1, shrink=0.55, pad=0.015, fraction=0.04)
    cbar.set_label('Water stress index (0 low – 1 high)', fontsize=6)
    cbar.ax.tick_params(labelsize=5)

    # Single consolidated legend (all entries as Line2D handles)
    legend_elements = [
        Line2D([0], [0], marker='o', color='w', markerfacecolor='#888888',
               markersize=5, label='Existing fab'),
        Line2D([0], [0], marker='^', color='w', markerfacecolor='#888888',
               markersize=5, label='Planned fab'),
        Line2D([0], [0], marker='*', color='w', markerfacecolor='#0066AA',
               markersize=6, label='Dam'),
        Line2D([0], [0], marker='s', color='w', markerfacecolor='#222222',
               markersize=3, label='City'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor='#888888',
               markersize=9, label='180k wfr/mo'),
        Line2D([0], [0], marker='o', color='w', markerfacecolor=P['navy'],
               markersize=5, label='>50% withdrawal increase'),
    ]
    ax1.legend(handles=legend_elements, frameon=True, fancybox=True,
               fontsize=5, loc='lower left', title='Legend',
               title_fontsize=5.5, ncol=3)

    # North arrow
    ax1.annotate('N', xy=(lon_max-0.15, lat_max-0.15),
                xytext=(lon_max-0.15, lat_max-0.30),
                arrowprops=dict(arrowstyle='->', lw=0.6, color='#444444'),
                fontsize=7, fontweight='bold', color='#444444',
                ha='center', va='bottom', zorder=9)
    # Scale bar (~30 km)
    scale_lon_start = lon_min + 0.15
    scale_lon_end   = scale_lon_start + 0.55  # ~30 km at 37N
    scale_lat = lat_min + 0.1
    ax1.plot([scale_lon_start, scale_lon_end], [scale_lat, scale_lat],
            color='#444444', lw=1.5, zorder=9, **kw_geo)
    ax1.plot([scale_lon_start, scale_lon_start], [scale_lat-0.01, scale_lat+0.01],
            color='#444444', lw=1, zorder=9, **kw_geo)
    ax1.plot([scale_lon_end, scale_lon_end], [scale_lat-0.01, scale_lat+0.01],
            color='#444444', lw=1, zorder=9, **kw_geo)
    ax1.text((scale_lon_start+scale_lon_end)/2, scale_lat-0.04, '30 km',
            fontsize=5.5, ha='center', color='#444444')

    # Title panel (a)
    ax1.set_title('a  Han River basin water stress and fab node distribution',
                 loc='left', fontweight='bold', pad=6, fontsize=8)
    ax1.set_xlabel('')   # grid labels already there
    ax1.set_ylabel('')

    # ═══════════════════════════════════════════════════════════════
    #  PANEL (b): Water supply-demand balance
    # ═══════════════════════════════════════════════════════════════
    ax2 = fig.add_subplot(gs[1, 0])
    ax2.set_position([0.10, 0.06, 0.85, 0.22])

    ax2.fill_between(wb.year, wb.supply_capacity_mcm, alpha=0.12, color=P['navy'])
    ax2.plot(wb.year, wb.supply_capacity_mcm, color=P['navy'], lw=1.5, ls='--',
            label='Supply capacity', zorder=4)

    for sc, clr in SCENARIO_COLORS.items():
        col = sc.lower().replace('-','_') + '_demand_mcm'
        ax2.plot(wb.year, wb[col], color=clr, lw=1, marker='o', ms=3.5,
                label=sc, zorder=4)

    # Phase annotations
    for yr, label, val in [(2031, 'Phase 1\n310k ton/d', 25),
                           (2035, 'Phase 2\n760k ton/d', 25)]:
        ax2.axvline(yr, c='grey', lw=0.4, ls=':', alpha=0.5, zorder=2)
        ax2.text(yr, val, label, fontsize=5.5, color='grey', ha='center',
                va='bottom', zorder=3)

    # Gap annotation
    ax2.annotate('', xy=(2035, 390), xytext=(2035, 180),
                arrowprops=dict(arrowstyle='<->', lw=0.5, color=P['crimson']),
                zorder=3)
    ax2.text(2036.5, 280, 'Max gap\n210 M m³', fontsize=5.5,
            color=P['crimson'], va='center')

    naturify(ax2, xlabel='Year', ylabel='Water volume\n(million m³ per year)')
    ax2.set_title('b  Water supply-demand balance', loc='left',
                 fontweight='bold', pad=8, fontsize=8)
    ax2.legend(frameon=True, fancybox=True, ncol=3, loc='upper left', fontsize=5.5)
    ax2.set_xlim(2024, 2050)
    ax2.set_ylim(0, 520)
    ax2.set_xticks([2025, 2030, 2035, 2040, 2045, 2050])

    # Grid lines
    ax2.grid(True, lw=0.2, alpha=0.3, axis='y')

    savefig(fig, 'Fig3_HanRiverBasin.pdf')


# ═══════════════════════════════════════════════════════════════════════
#  FIGURE 4 — Electricity cost (double column, two panels)
# ═══════════════════════════════════════════════════════════════════════
def fig4_electricity():
    cost = load('electricity_cost_by_region.csv')
    inv  = load('electricity_investment_costs.csv')

    fig = plt.figure(figsize=(NATURE_PAGE_WIDTH, 3.5))
    gs  = fig.add_gridspec(1, 2, width_ratios=[1.2, 1], wspace=0.35,
                           left=0.07, right=0.80, bottom=0.27, top=0.90)

    # Panel (a): marginal cost by region
    ax1 = fig.add_subplot(gs[0, 0])
    regions = ['Seoul-Gyeonggi', 'Chungcheong', 'Honam', 'Yeongnam']
    region_labels = ['Seoul-\nGyeonggi', 'Chungcheong', 'Honam', 'Yeongnam']
    x = np.arange(len(regions))
    w = 0.22

    for i, (sc, clr) in enumerate(SCENARIO_COLORS.items()):
        vals = cost[cost.scenario==sc].set_index('region').loc[regions, 'marginal_cost_won_kwh']
        off = (i - 1) * w
        bars = ax1.bar(x + off, vals, w, color=clr, label=sc, ec='white', lw=0.3)
        for b, v in zip(bars, vals):
            ax1.text(b.get_x()+b.get_width()/2, b.get_height()+0.5,
                     f'{v:.0f}', ha='center', fontsize=5.5, fontweight='bold')

    ax1.set_xticks(x)
    ax1.set_xticklabels(region_labels, fontsize=5)
    naturify(ax1, ylabel='Marginal cost (won/kWh)')
    ax1.set_title('a  Marginal cost by region', loc='left',
                 fontweight='bold', pad=8, fontsize=8)
    ax1.legend(frameon=True, fancybox=True, loc='upper center', bbox_to_anchor=(0.5, -0.30),
               ncol=3, fontsize=5.5)

    # Panel (b): investment costs stacked
    ax2 = fig.add_subplot(gs[0, 1])
    costs = ['Generation', 'Transmission', 'RE100 Procurement', 'Storage']
    c_clr = [P['navy'], P['light_blue'], P['steel_blue'], P['crimson']]

    x2 = np.arange(3)
    w2 = 0.5
    bottoms = np.zeros(3)
    for cat, clr in zip(costs, c_clr):
        vals = []
        for s in list(SCENARIO_COLORS.keys()):
            r = inv[(inv.cost_category==cat) & (inv.scenario==s)]
            vals.append(r['annualized_cost_usd_billion'].values[0] if len(r) else 0)
        ax2.bar(x2, vals, w2, bottom=bottoms, color=clr, label=cat, ec='white', lw=0.3)
        bottoms += vals

    ax2.set_xticks(x2)
    ax2.set_xticklabels(list(SCENARIO_COLORS.keys()), fontsize=6.5)
    naturify(ax2, ylabel='Annualized cost (billion USD per year)')
    ax2.set_title('b  Investment costs by category', loc='left',
                 fontweight='bold', pad=8, fontsize=8)
    ax2.legend(frameon=True, fancybox=True, loc='upper left', bbox_to_anchor=(1.02, 1), fontsize=6)

    savefig(fig, 'Fig4_Electricity.pdf')


# ═══════════════════════════════════════════════════════════════════════
#  FIGURE 5 — Land use & spatial concentration
# ═══════════════════════════════════════════════════════════════════════
def fig5_land_concentration():
    lu = load('land_use_by_scenario.csv')

    fig = plt.figure(figsize=(NATURE_PAGE_WIDTH, 4.5))
    gs  = fig.add_gridspec(1, 2, width_ratios=[1.5, 1.1], wspace=0.45,
                           left=0.09, right=0.97, bottom=0.16, top=0.92)

    # ── Panel (a): land use by category ──
    ax1 = fig.add_subplot(gs[0, 0])
    lu_sub = lu[~lu.land_category.isin(['Total'])]
    cats = lu_sub.land_category.tolist()
    cmap = {'Baseline':'baseline_ha','AI-Explosion':'ai_explosion_ha',
            'Eco-Constraint':'eco_constraint_ha'}
    x = np.arange(len(cats))
    w = 0.22

    for i, (sc, clr) in enumerate(SCENARIO_COLORS.items()):
        off = (i - 1) * w
        ax1.bar(x + off, lu_sub[cmap[sc]], w, color=clr, label=sc,
                ec='white', lw=0.3)

    # Calculate max bar height for y-limit with headroom
    max_h = max(
        lu_sub[['baseline_ha', 'ai_explosion_ha', 'eco_constraint_ha']].max().max(),
        2800
    )
    ax1.set_ylim(0, max_h * 1.35)

    # Total annotations — staggered vertically in top-right corner
    for i, (sc, clr) in enumerate(SCENARIO_COLORS.items()):
        t = lu[lu.land_category=='Total'][cmap[sc]].values[0]
        y_pos = max_h * 1.04 + i * max_h * 0.10
        ax1.text(len(cats) - 0.5, y_pos, f'Total {sc}: {t:.0f} ha',
                fontsize=5.5, color=clr, fontweight='bold',
                ha='right', va='bottom')

    ax1.set_xticks(x)
    ax1.set_xticklabels([c.replace(' ','\n') for c in cats], fontsize=4.5)
    naturify(ax1, ylabel='Land area (ha)')
    ax1.set_title('a  Land requirements by category', loc='left',
                 fontweight='bold', pad=8, fontsize=8)
    ax1.legend(frameon=True, fancybox=True, loc='upper left')

    # ── Panel (b): concentration metrics ──
    ax2 = fig.add_subplot(gs[0, 1])
    items = [
        ('Population in capital region',   51, '%', P['navy']),
        ('Semiconductor employment share', 72, '%', P['crimson']),
        ('Supplier company share',         80, '%', P['crimson']),
        ('Capital region land area',        12, '%', P['steel_blue']),
        ('Extinction-risk districts',     130, '',  P['purple']),
        ('Gini (fab capacity, x100)',      78, '',  P['purple']),
    ]
    labels = [it[0] for it in items]
    values = [it[1] for it in items]
    colors = [it[3] for it in items]

    bars = ax2.barh(labels, values, color=colors, ec='white', lw=0.3, height=0.55)
    for b, v, u in zip(bars, values, [it[2] for it in items]):
        ax2.text(b.get_width() + 1.0, b.get_y() + b.get_height()/2,
                 f'{v}{" "+u if u else ""}', va='center', fontsize=7)

    ax2.set_xlim(0, 165)
    ax2.tick_params(axis='y', labelsize=6.5)
    naturify(ax2, xlabel='Metric value')
    ax2.set_title('b  Spatial concentration indicators', loc='left',
                 fontweight='bold', pad=8, fontsize=8)

    savefig(fig, 'Fig5_LandConcentration.pdf')


# ═══════════════════════════════════════════════════════════════════════
#  FIGURE 6 — XGBoost/SHAP feature importance
# ═══════════════════════════════════════════════════════════════════════
def fig6_shap():
    df = load('xgb_shap_values.csv').sort_values('mean_shap_value', ascending=True)

    fig, ax = plt.subplots(figsize=(NATURE_COL_WIDTH, 3.5))
    fig.subplots_adjust(left=0.32, right=0.92, bottom=0.10, top=0.92)

    y = np.arange(len(df))
    v = df['mean_shap_value'].values
    e = v - df['ci_lower_95'].values
    e2 = df['ci_upper_95'].values - v

    label_map = {
        'Local baseline water stress': 'Baseline water stress',
        'Distance to low-cost generation': 'Dist. to low-cost gen.',
        'Fab energy efficiency': 'Energy efficiency',
        'Process node advancement': 'Process node',
        'Distance to offshore wind': 'Dist. to offshore wind',
        'Transmission capacity margin': 'Transmission capacity',
        'Water source type': 'Water source type',
    }
    labs = [label_map.get(l, l) for l in df['feature']]

    # Sequential gradient from the reference palette (navy → steel_blue → light_blue)
    nature_seq = ['#3063A2', '#498EB8', '#95BFD7'][::-1]
    nature_cmap = LinearSegmentedColormap.from_list('nature_seq', nature_seq)
    clrs = [nature_cmap(i / max(1, len(df) - 1)) for i in range(len(df))]
    ax.barh(y, v, xerr=[e, e2], color=clrs, ec='white', lw=0.3,
            height=0.55, capsize=2.5)

    ax.set_yticks(y)
    ax.set_yticklabels(labs)
    ax.set_xlabel('Mean |SHAP value|')
    ax.set_title('Feature importance (95% bootstrap CI)', fontweight='bold', pad=6)
    ax.tick_params(direction='out')
    ax.axvline(0, c='grey', lw=0.4)

    savefig(fig, 'Fig6_SHAP.pdf')


# ═══════════════════════════════════════════════════════════════════════
#  SUPPLEMENTARY — Generation mix transition
# ═══════════════════════════════════════════════════════════════════════
def fig_s1_generation_mix():
    df = load('generation_mix.csv')
    clr_map = {
        'Nuclear':    P['crimson'],
        'LNG':        P['light_blue'],
        'Coal':       P['navy'],
        'Renewables': P['steel_blue'],
        'Hydrogen':   P['purple'],
        'Storage':    P['brick'],
        'Oil':        P['peach'],
    }

    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(NATURE_PAGE_WIDTH, 3.2))
    fig.subplots_adjust(wspace=0.3, bottom=0.05)

    for ax, yr, title in [(ax1, 2024, '2024 actual'),
                          (ax2, 2038, '2038 target (11th Plan)')]:
        sub = df[df.year == yr]
        wedges, _, autotexts = ax.pie(
            sub['share_pct'], autopct='%1.1f%%',
            colors=[clr_map[s] for s in sub['source']],
            startangle=90, pctdistance=0.75,
            textprops={'fontsize': 6.5})
        for t in autotexts:
            t.set_fontweight('bold')
        ax.set_title(title, fontweight='bold', fontsize=8, pad=8)

    fig.legend(wedges, sub['source'].values, loc='lower center',
               ncol=7, fontsize=6.5, frameon=False)

    savefig(fig, 'FigS1_GenerationMix.pdf')


# ═══════════════════════════════════════════════════════════════════════
#  MAIN
# ═══════════════════════════════════════════════════════════════════════
if __name__ == '__main__':
    print("=" * 55)
    print("Nature Sustainability — Figure Generation")
    print(f"Output: {OUTPUT_DIR}")
    print(f"cartopy available: {HAS_CARTOPY}")
    print("=" * 55)

    tasks = [
        ('Fig 2 — Water stress categories',      fig2_water_stress),
        # Fig 3 is generated by fig3_han_river_basin.py (OSM-based)
        # ('Fig 3 — Han River basin map + balance', fig3_han_river_map),
        ('Fig 4 — Electricity cost & investment', fig4_electricity),
        ('Fig 5 — Land use & concentration',     fig5_land_concentration),
        ('Fig 6 — SHAP feature importance',       fig6_shap),
        ('Fig S1 — Generation mix transition',    fig_s1_generation_mix),
    ]

    for label, fn in tasks:
        print(f"\n  {label} ...")
        try:
            fn()
        except Exception as e:
            print(f"  X FAILED: {e}")
            import traceback
            traceback.print_exc()

    print(f"\n{'='*55}")
    print(f"All figures saved to: {OUTPUT_DIR}")
    print(f"{'='*55}")
